"""
main_gui.py — Dashboard Principal del Sistema de Invernadero Inteligente
"""

import tkinter as tk
import subprocess, sys, os, math

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, BASE_DIR)
from sensor_data import get_manager

try:
    import matplotlib; matplotlib.use("TkAgg")
    from matplotlib.figure import Figure
    from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
    HAS_MPL = True
except ImportError:
    HAS_MPL = False

# ─── Paleta blanca profesional ────────────────────────────────────────────────
BG     = "#F5F7FA"
BG2    = "#FFFFFF"
BG3    = "#EAEEf3"
BORDER = "#D5DCE6"
GREEN  = "#2E7D32"
RED    = "#D32F2F"
ORANGE = "#E64A19"
GOLD   = "#F9A825"
BLUE   = "#1565C0"
TEXT   = "#1C2833"
TEXT2  = "#5D6D7E"
TDIM   = "#95A5A6"

C_TOMATE   = "#C62828"; C_TOMATE_H   = "#E53935"
C_LECHUGA  = "#2E7D32"; C_LECHUGA_H  = "#388E3C"
C_PIMIENTO = "#E65100"; C_PIMIENTO_H = "#F4511E"
C_GENERAL  = "#1565C0"; C_GENERAL_H  = "#1976D2"

FS = ("Segoe UI", 9)
FB = ("Segoe UI", 9, "bold")


def gauge_color(v, lo, hi):
    if lo <= v <= hi: return GREEN
    if v < lo*0.85 or v > hi*1.15: return RED
    return ORANGE


class Gauge(tk.Canvas):
    def __init__(self, parent, label, unit, lo, hi, vmin=0, vmax=100, size=140, **kw):
        super().__init__(parent, width=size, height=size,
                         bg=BG2, highlightthickness=0, **kw)
        self.size, self.label, self.unit = size, label, unit
        self.lo, self.hi, self.vmin, self.vmax = lo, hi, vmin, vmax
        self._v = (lo + hi) / 2
        self._draw()

    def _draw(self):
        self.delete("all")
        s, cx, cy = self.size, self.size//2, self.size//2
        r = s//2 - 14
        self.create_arc(cx-r, cy-r, cx+r, cy+r, start=220, extent=-260,
                        style="arc", outline=BG3, width=12)
        pct = (self._v - self.vmin) / max(1, self.vmax - self.vmin)
        sw  = pct * 260
        col = gauge_color(self._v, self.lo, self.hi)
        if sw > 0:
            self.create_arc(cx-r, cy-r, cx+r, cy+r, start=220, extent=-sw,
                            style="arc", outline=col, width=12)
        ang = math.radians(220 - sw)
        px, py = cx+(r-6)*math.cos(ang), cy-(r-6)*math.sin(ang)
        self.create_oval(px-5, py-5, px+5, py+5, fill=col, outline=BG2, width=2)
        self.create_text(cx, cy-10, text=f"{self._v:.1f}", fill=col,
                         font=("Segoe UI", int(s*0.13), "bold"))
        self.create_text(cx, cy+7,  text=self.unit, fill=TEXT2,
                         font=("Segoe UI", int(s*0.07)))
        self.create_text(cx, cy+24, text=self.label, fill=TEXT,
                         font=("Segoe UI", int(s*0.065), "bold"))

    def set_value(self, v):
        self._v = v; self._draw()


def card(parent, pady=0):
    outer = tk.Frame(parent, bg=BORDER, padx=1, pady=1)
    outer.pack(fill="x", pady=pady)
    inner = tk.Frame(outer, bg=BG2)
    inner.pack(fill="both", expand=True)
    return inner


class MainApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("🌿 Sistema de Invernadero Inteligente")
        self.configure(bg=BG)
        self.state("zoomed")
        self.minsize(1024, 700)
        self.resizable(True, True)
        self.manager = get_manager()
        self._build_ui()
        self._update()

    def _build_ui(self):
        # Header
        hdr = tk.Frame(self, bg=BG2, height=58)
        hdr.pack(fill="x"); hdr.pack_propagate(False)
        tk.Frame(self, bg=BORDER, height=1).pack(fill="x")

        tk.Label(hdr, text="🌿  INVERNADERO INTELIGENTE",
                 bg=BG2, fg=GREEN, font=("Segoe UI", 20, "bold")).pack(side="left", padx=22, pady=10)

        inf = tk.Frame(hdr, bg=BG2); inf.pack(side="right", padx=22, pady=8)
        self.lbl_time = tk.Label(inf, text="--:--:--", bg=BG2, fg=TEXT,
                                 font=("Segoe UI", 14, "bold")); self.lbl_time.pack(anchor="e")
        self.lbl_date = tk.Label(inf, text="", bg=BG2, fg=TEXT2, font=FS); self.lbl_date.pack(anchor="e")
        self.lbl_ext  = tk.Label(inf, text="", bg=BG2, fg=TEXT2, font=FS); self.lbl_ext.pack(anchor="e")

        # Body
        body = tk.Frame(self, bg=BG)
        body.pack(fill="both", expand=True, padx=16, pady=12)
        body.columnconfigure(1, weight=1)
        body.rowconfigure(0, weight=1)

        left = tk.Frame(body, bg=BG)
        left.grid(row=0, column=0, sticky="ns", padx=(0, 14))
        self._gauges(left)
        self._status(left)
        self._controls(left)
        self._buttons(left)

        right = tk.Frame(body, bg=BG)
        right.grid(row=0, column=1, sticky="nsew")
        self._graphs(right)

    def _gauges(self, p):
        c = card(p, pady=(0, 8))
        tk.Label(c, text="SENSORES", bg=BG2, fg=TDIM, font=FB).pack(pady=(8, 4))
        row = tk.Frame(c, bg=BG2); row.pack(pady=(0, 8))
        self.g_temp = Gauge(row, "TEMP.", "°C", 18, 30, 0, 45, 130)
        self.g_temp.grid(row=0, column=0, padx=8)
        self.g_hum  = Gauge(row, "HUMEDAD", "%", 60, 85, 0, 100, 130)
        self.g_hum.grid(row=0, column=1, padx=8)
        self.g_lum  = Gauge(row, "LUZ", "%", 50, 90, 0, 100, 130)
        self.g_lum.grid(row=0, column=2, padx=8)

    def _status(self, p):
        c = card(p, pady=(0, 8))
        tk.Label(c, text="VALORES ACTUALES", bg=BG2, fg=TDIM, font=FB).pack(pady=(8, 4))
        row = tk.Frame(c, bg=BG2); row.pack(pady=(0, 8))
        for title, attr, col in [("🌡 Temp.", "st_t", RED),
                                  ("💧 Hum.",  "st_h", BLUE),
                                  ("☀ Luz",    "st_l", GOLD)]:
            f = tk.Frame(row, bg=BG3, padx=12, pady=6); f.pack(side="left", padx=6)
            tk.Label(f, text=title, bg=BG3, fg=TEXT2, font=FS).pack()
            lb = tk.Label(f, text="--", bg=BG3, fg=col, font=("Segoe UI", 12, "bold")); lb.pack()
            setattr(self, attr, lb)

    def _controls(self, p):
        c = card(p, pady=(0, 8))
        tk.Label(c, text="CONTROL MANUAL", bg=BG2, fg=TDIM, font=FB).pack(pady=(8, 2))

        def upd(v=None):
            self.manager.set_manual_values(self.s_t.get(), self.s_h.get(), self.s_l.get())

        cfg = dict(orient="horizontal", bg=BG2, fg=TEXT, highlightthickness=0,
                   troughcolor=BG3, font=FS, command=upd, relief="flat",
                   sliderlength=18, bd=0, length=340)

        self.s_t = tk.Scale(c, from_=10, to=45, resolution=0.5,
                            label="🌡 Temperatura (°C)", **cfg)
        self.s_t.set(self.manager._base_temp); self.s_t.pack(padx=12)

        self.s_h = tk.Scale(c, from_=0, to=100, resolution=1,
                            label="💧 Humedad (%)", **cfg)
        self.s_h.set(self.manager._base_humidity); self.s_h.pack(padx=12)

        self.s_l = tk.Scale(c, from_=0, to=100, resolution=1,
                            label="☀ Luminosidad (%)", **cfg)
        self.s_l.set(self.manager._base_luminosity); self.s_l.pack(padx=12, pady=(0, 8))

    def _buttons(self, p):
        c = card(p)
        tk.Label(c, text="SELECCIONAR CULTIVO", bg=BG2, fg=TDIM, font=FB).pack(pady=(8, 6))
        for txt, bg_d, bg_h, script in [
            ("🍅   TOMATE",   C_TOMATE,   C_TOMATE_H,   "tomate_gui.py"),
            ("🥬   LECHUGA",  C_LECHUGA,  C_LECHUGA_H,  "lechuga_gui.py"),
            ("🫑   PIMIENTO", C_PIMIENTO, C_PIMIENTO_H, "pimiento_gui.py"),
            ("⚙    GENERAL",  C_GENERAL,  C_GENERAL_H,  "general_gui.py"),
        ]:
            btn = tk.Button(c, text=txt, bg=bg_d, fg="white",
                            activebackground=bg_h, activeforeground="white",
                            font=("Segoe UI", 11, "bold"), relief="flat", bd=0,
                            pady=9, padx=12, cursor="hand2",
                            command=lambda s=script: self._go(s))
            btn.pack(fill="x", padx=12, pady=3)
            btn.bind("<Enter>", lambda e, b=btn, c=bg_h: b.config(bg=c))
            btn.bind("<Leave>", lambda e, b=btn, c=bg_d: b.config(bg=c))
        tk.Frame(c, bg=BG2, height=8).pack()

    def _graphs(self, p):
        outer = tk.Frame(p, bg=BORDER, padx=1, pady=1)
        outer.pack(fill="both", expand=True)
        c = tk.Frame(outer, bg=BG2); c.pack(fill="both", expand=True)
        tk.Label(c, text="GRÁFICAS EN TIEMPO REAL", bg=BG2, fg=TDIM, font=FB).pack(pady=(10, 2))

        if not HAS_MPL:
            tk.Label(c, text="Instala matplotlib", bg=BG2, fg=ORANGE).pack(expand=True)
            return

        self.fig = Figure(dpi=92)
        self.fig.patch.set_facecolor(BG2)
        cfgs = [(311,"Temperatura (°C)","#E53935",list(self.manager.history["temperature"])),
                (312,"Humedad (%)","#1976D2",list(self.manager.history["humidity"])),
                (313,"Luminosidad (%)","#F9A825",list(self.manager.history["luminosity"]))]
        self.axes, self.lines = [], []
        for pos, lbl, col, data in cfgs:
            ax = self.fig.add_subplot(pos)
            ax.set_facecolor(BG3)
            ax.tick_params(colors=TEXT2, labelsize=7)
            ax.set_ylabel(lbl, fontsize=7, color=TEXT2)
            for sp in ax.spines.values(): sp.set_edgecolor(BORDER)
            ln, = ax.plot(data, color=col, linewidth=1.8)
            ax.fill_between(range(len(data)), data, alpha=0.09, color=col)
            ax.set_xlim(0, 60)
            self.axes.append(ax); self.lines.append(ln)
        self.fig.tight_layout(pad=1.2)
        cv = FigureCanvasTkAgg(self.fig, master=c)
        cv.draw()
        cv.get_tk_widget().pack(fill="both", expand=True, padx=12, pady=(2, 12))
        self.canvas_fig = cv

    def _update(self):
        d = self.manager.current
        self.g_temp.set_value(d.temperature)
        self.g_hum.set_value(d.humidity)
        self.g_lum.set_value(d.luminosity)
        self.st_t.config(text=f"{d.temperature:.1f} °C")
        self.st_h.config(text=f"{d.humidity:.1f} %")
        self.st_l.config(text=f"{d.luminosity:.1f} %")
        self.lbl_time.config(text=self.manager.get_colombia_time_str())
        self.lbl_date.config(text=self.manager.get_colombia_date_str())
        self.lbl_ext.config(text=f"🌡 Ext: {d.exterior_temp:.1f} °C")
        if HAS_MPL:
            keys = ["temperature","humidity","luminosity"]
            cols = ["#E53935","#1976D2","#F9A825"]
            for i, key in enumerate(keys):
                hist = list(self.manager.history[key])
                x = list(range(len(hist)))
                self.lines[i].set_data(x, hist)
                for coll in self.axes[i].collections: coll.remove()
                self.axes[i].fill_between(x, hist, alpha=0.09, color=cols[i])
                mn, mx = min(hist), max(hist)
                mg = max(1, (mx-mn)*0.2)
                self.axes[i].set_ylim(mn-mg, mx+mg)
            self.canvas_fig.draw_idle()
        self.after(1000, self._update)

    def _go(self, script):
        path = os.path.join(BASE_DIR, script)
        if os.path.exists(path):
            subprocess.Popen([sys.executable, path])
            self.destroy()
        else:
            tk.messagebox.showerror("Error", f"No encontrado: {script}")


if __name__ == "__main__":
    MainApp().mainloop()

"""
main_gui.py — Dashboard Principal del Sistema de Invernadero Inteligente
Muestra temperatura, humedad y luminosidad en tiempo real.
Botones para acceder a cada cultivo y configuración general.
"""

import tkinter as tk
from tkinter import font as tkfont
import subprocess
import sys
import os
import math
import time

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, BASE_DIR)

from sensor_data import get_manager

try:
    import matplotlib
    matplotlib.use("TkAgg")
    from matplotlib.figure import Figure
    from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
    HAS_MATPLOTLIB = True
except ImportError:
    HAS_MATPLOTLIB = False

# ─── Colores ────────────────────────────────────────────────────────────────
BG        = "#0d1f0d"
BG2       = "#152515"
BG3       = "#1e3a1e"
ACCENT    = "#4CAF50"
ACCENT2   = "#81C784"
GOLD      = "#FFD54F"
RED       = "#EF5350"
ORANGE    = "#FF7043"
TEXT      = "#E8F5E9"
TEXT2     = "#A5D6A7"
TEXT_DIM  = "#4a7a4a"

FONT_TITLE  = ("Segoe UI", 22, "bold")
FONT_BODY   = ("Segoe UI", 11)
FONT_SMALL  = ("Segoe UI", 9)
FONT_GAUGE  = ("Segoe UI", 18, "bold")
FONT_LABEL  = ("Segoe UI", 10, "bold")


def gauge_color(val, low, high):
    """Devuelve color según si el valor está en rango, bajo o alto."""
    if low <= val <= high:
        return ACCENT
    elif val < low * 0.85 or val > high * 1.15:
        return RED
    return ORANGE


class GaugeWidget(tk.Canvas):
    """Gauge circular animado."""
    def __init__(self, parent, label, unit, low, high, vmin=0, vmax=100, **kw):
        size = kw.pop("size", 160)
        super().__init__(parent, width=size, height=size,
                         bg=BG2, highlightthickness=0, **kw)
        self.size   = size
        self.label  = label
        self.unit   = unit
        self.low    = low
        self.high   = high
        self.vmin   = vmin
        self.vmax   = vmax
        self._value = (low + high) / 2
        self._draw()

    def _draw(self):
        self.delete("all")
        s, cx, cy = self.size, self.size // 2, self.size // 2
        r = s // 2 - 12

        # Arco de fondo
        self.create_arc(cx - r, cy - r, cx + r, cy + r,
                        start=220, extent=-260,
                        style="arc", outline=BG3, width=12)

        # Arco de valor
        pct   = (self._value - self.vmin) / max(1, self.vmax - self.vmin)
        sweep = pct * 260
        color = gauge_color(self._value, self.low, self.high)
        if sweep > 0:
            self.create_arc(cx - r, cy - r, cx + r, cy + r,
                            start=220, extent=-sweep,
                            style="arc", outline=color, width=12)

        # Puntero (línea)
        angle_deg = 220 - sweep
        angle_rad = math.radians(angle_deg)
        px = cx + (r - 6) * math.cos(angle_rad)
        py = cy - (r - 6) * math.sin(angle_rad)
        self.create_oval(px - 5, py - 5, px + 5, py + 5, fill=color, outline="")

        # Valor
        val_str = f"{self._value:.1f}"
        self.create_text(cx, cy - 10, text=val_str, fill=color,
                         font=("Segoe UI", int(s * 0.14), "bold"))
        self.create_text(cx, cy + 10, text=self.unit, fill=TEXT2,
                         font=("Segoe UI", int(s * 0.075)))
        self.create_text(cx, cy + 30, text=self.label, fill=TEXT2,
                         font=("Segoe UI", int(s * 0.07), "bold"))

    def set_value(self, val):
        self._value = val
        self._draw()


class MainApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("🌿 Sistema de Invernadero Inteligente")
        self.configure(bg=BG)
        self.geometry("1100x750")
        self.minsize(900, 650)
        self.resizable(True, True)

        self.manager = get_manager()
        self._build_ui()
        self._start_updates()

    # ── Construcción de UI ───────────────────────────────────────────────────
    def _build_ui(self):
        # Header
        header = tk.Frame(self, bg=BG2, height=70)
        header.pack(fill="x", padx=0, pady=0)
        header.pack_propagate(False)

        tk.Label(header, text="🌿 INVERNADERO INTELIGENTE",
                 bg=BG2, fg=ACCENT, font=FONT_TITLE).pack(side="left", padx=20, pady=10)

        info_frame = tk.Frame(header, bg=BG2)
        info_frame.pack(side="right", padx=20, pady=5)

        self.lbl_time = tk.Label(info_frame, text="--:--:--",
                                 bg=BG2, fg=GOLD, font=("Segoe UI", 15, "bold"))
        self.lbl_time.pack(anchor="e")
        self.lbl_date = tk.Label(info_frame, text="Colombia",
                                 bg=BG2, fg=TEXT2, font=FONT_SMALL)
        self.lbl_date.pack(anchor="e")
        self.lbl_ext = tk.Label(info_frame, text="🌡 Ext: -- °C",
                                bg=BG2, fg=TEXT2, font=FONT_SMALL)
        self.lbl_ext.pack(anchor="e")

        # Área principal
        main = tk.Frame(self, bg=BG)
        main.pack(fill="both", expand=True, padx=10, pady=8)

        # Columna izquierda: gauges + status + controles + botones
        left = tk.Frame(main, bg=BG)
        left.pack(side="left", fill="y", padx=(0, 8))
        self._build_gauges(left)
        self._build_status(left)
        self._build_controls(left)
        self._build_buttons(left)

        # Columna derecha: gráficas
        right = tk.Frame(main, bg=BG2, bd=0)
        right.pack(side="left", fill="both", expand=True)
        self._build_graphs(right)

    def _build_gauges(self, parent):
        frame = tk.Frame(parent, bg=BG2, bd=0, relief="flat")
        frame.pack(fill="x", pady=(0, 8))

        tk.Label(frame, text="SENSORES EN TIEMPO REAL",
                 bg=BG2, fg=TEXT_DIM, font=("Segoe UI", 9, "bold")).pack(pady=(8, 4))

        gauges_row = tk.Frame(frame, bg=BG2)
        gauges_row.pack(pady=4)

        self.g_temp = GaugeWidget(gauges_row, "TEMPERATURA", "°C",
                                   low=18, high=30, vmin=0, vmax=45, size=145)
        self.g_temp.grid(row=0, column=0, padx=6)

        self.g_hum = GaugeWidget(gauges_row, "HUMEDAD", "%",
                                  low=60, high=85, vmin=0, vmax=100, size=145)
        self.g_hum.grid(row=0, column=1, padx=6)

        self.g_lum = GaugeWidget(gauges_row, "LUMINOSIDAD", "%",
                                  low=50, high=90, vmin=0, vmax=100, size=145)
        self.g_lum.grid(row=0, column=2, padx=6)

    def _build_status(self, parent):
        frame = tk.Frame(parent, bg=BG2)
        frame.pack(fill="x", pady=(0, 8))

        tk.Label(frame, text="ESTADO GENERAL DEL SISTEMA",
                 bg=BG2, fg=TEXT_DIM, font=("Segoe UI", 9, "bold")).pack(pady=(8, 4))

        row = tk.Frame(frame, bg=BG2)
        row.pack()

        cols = [
            ("🌡 Temperatura", "stat_temp"),
            ("💧 Humedad",     "stat_hum"),
            ("☀ Luminosidad",  "stat_lum"),
        ]
        for title, attr in cols:
            col = tk.Frame(row, bg=BG3, padx=10, pady=6)
            col.pack(side="left", padx=4, pady=4)
            tk.Label(col, text=title, bg=BG3, fg=TEXT2, font=FONT_SMALL).pack()
            lbl = tk.Label(col, text="--", bg=BG3, fg=ACCENT, font=("Segoe UI", 11, "bold"))
            lbl.pack()
            setattr(self, attr, lbl)

    def _build_controls(self, parent):
        frame = tk.Frame(parent, bg=BG2)
        frame.pack(fill="x", pady=(0, 8))

        tk.Label(frame, text="CONTROL MANUAL DE VARIABLES",
                 bg=BG2, fg=TEXT_DIM, font=("Segoe UI", 9, "bold")).pack(pady=(4, 2))

        def update_values(val=None):
            self.manager.set_manual_values(self.scale_temp.get(), self.scale_hum.get(), self.scale_lum.get())

        self.scale_temp = tk.Scale(frame, from_=10, to=45, resolution=0.5, orient="horizontal", bg=BG2, fg=TEXT, highlightthickness=0, label="🌡 Temperatura (°C)", command=update_values, troughcolor=BG3, font=FONT_SMALL)
        self.scale_temp.set(self.manager._base_temp)
        self.scale_temp.pack(fill="x", padx=10)

        self.scale_hum = tk.Scale(frame, from_=0, to=100, resolution=1, orient="horizontal", bg=BG2, fg=TEXT, highlightthickness=0, label="💧 Humedad (%)", command=update_values, troughcolor=BG3, font=FONT_SMALL)
        self.scale_hum.set(self.manager._base_humidity)
        self.scale_hum.pack(fill="x", padx=10)

        self.scale_lum = tk.Scale(frame, from_=0, to=100, resolution=1, orient="horizontal", bg=BG2, fg=TEXT, highlightthickness=0, label="☀ Luminosidad (%)", command=update_values, troughcolor=BG3, font=FONT_SMALL)
        self.scale_lum.set(self.manager._base_luminosity)
        self.scale_lum.pack(fill="x", padx=10, pady=(0, 6))

    def _build_buttons(self, parent):
        frame = tk.Frame(parent, bg=BG)
        frame.pack(fill="x", pady=4)

        tk.Label(frame, text="SELECCIONAR CULTIVO",
                 bg=BG, fg=TEXT_DIM, font=("Segoe UI", 9, "bold")).pack(pady=(4, 6))

        btn_data = [
            ("🍅  TOMATE",    "#c62828", "#e53935", "tomate_gui.py"),
            ("🥬  LECHUGA",   "#1b5e20", "#2e7d32", "lechuga_gui.py"),
            ("🫑  PIMIENTO",  "#e65100", "#f4511e", "pimiento_gui.py"),
            ("⚙   GENERAL",   "#1a237e", "#283593", "general_gui.py"),
        ]
        for txt, bg_dark, bg_light, script in btn_data:
            btn = tk.Button(
                frame, text=txt,
                bg=bg_dark, fg="white",
                activebackground=bg_light, activeforeground="white",
                font=("Segoe UI", 12, "bold"),
                relief="flat", bd=0, pady=10, padx=14, cursor="hand2",
                command=lambda s=script: self._open_window(s),
            )
            btn.pack(fill="x", padx=10, pady=3)
            btn.bind("<Enter>", lambda e, b=btn, c=bg_light: b.config(bg=c))
            btn.bind("<Leave>", lambda e, b=btn, c=bg_dark:  b.config(bg=c))

    def _build_graphs(self, parent):
        tk.Label(parent, text="GRÁFICAS EN TIEMPO REAL",
                 bg=BG2, fg=TEXT_DIM, font=("Segoe UI", 9, "bold")).pack(pady=(10, 4))

        if not HAS_MATPLOTLIB:
            tk.Label(parent, text="Instala matplotlib para ver gráficas\n(ejecuta instalar.bat)",
                     bg=BG2, fg=ORANGE, font=FONT_BODY).pack(expand=True)
            return

        self.fig = Figure(figsize=(5.5, 5), dpi=90)
        self.fig.patch.set_facecolor(BG2)

        axes_cfg = [
            (311, "Temperatura (°C)", ACCENT,   list(self.manager.history["temperature"])),
            (312, "Humedad (%)",       "#42A5F5", list(self.manager.history["humidity"])),
            (313, "Luminosidad (%)",   GOLD,      list(self.manager.history["luminosity"])),
        ]
        self.axes = []
        self.lines = []
        self.graph_data = {
            "temperature": list(self.manager.history["temperature"]),
            "humidity":    list(self.manager.history["humidity"]),
            "luminosity":  list(self.manager.history["luminosity"]),
        }

        for pos, ylabel, color, data in axes_cfg:
            ax = self.fig.add_subplot(pos)
            ax.set_facecolor(BG3)
            ax.tick_params(colors=TEXT2, labelsize=7)
            ax.yaxis.label.set_color(TEXT2)
            ax.set_ylabel(ylabel, fontsize=8, color=TEXT2)
            for spine in ax.spines.values():
                spine.set_edgecolor(TEXT_DIM)
            line, = ax.plot(data, color=color, linewidth=1.5)
            ax.set_xlim(0, 60)
            self.axes.append(ax)
            self.lines.append(line)

        self.fig.tight_layout(pad=1.2)

        canvas = FigureCanvasTkAgg(self.fig, master=parent)
        canvas.draw()
        canvas.get_tk_widget().pack(fill="both", expand=True, padx=8, pady=(0, 8))
        self.canvas_fig = canvas

    # ── Actualizaciones ──────────────────────────────────────────────────────
    def _start_updates(self):
        self._update_all()

    def _update_all(self):
        data = self.manager.current

        # Gauges
        self.g_temp.set_value(data.temperature)
        self.g_hum.set_value(data.humidity)
        self.g_lum.set_value(data.luminosity)

        # Stats
        self.stat_temp.config(text=f"{data.temperature:.1f} °C")
        self.stat_hum.config(text=f"{data.humidity:.1f} %")
        self.stat_lum.config(text=f"{data.luminosity:.1f} %")

        # Tiempo Colombia
        self.lbl_time.config(text=self.manager.get_colombia_time_str())
        self.lbl_date.config(text=self.manager.get_colombia_date_str())
        self.lbl_ext.config(text=f"🌡 Ext: {data.exterior_temp:.1f} °C")

        # Gráficas
        if HAS_MATPLOTLIB:
            keys = ["temperature", "humidity", "luminosity"]
            for i, key in enumerate(keys):
                hist = list(self.manager.history[key])
                self.lines[i].set_ydata(hist)
                mn, mx = min(hist), max(hist)
                margin = max(1, (mx - mn) * 0.15)
                self.axes[i].set_ylim(mn - margin, mx + margin)
            self.canvas_fig.draw_idle()

        self.after(1000, self._update_all)

    # ── Abrir ventana secundaria ─────────────────────────────────────────────
    def _open_window(self, script_name):
        script_path = os.path.join(BASE_DIR, script_name)
        if os.path.exists(script_path):
            subprocess.Popen([sys.executable, script_path])
            self.destroy()
        else:
            tk.messagebox.showerror("Error", f"No se encontró {script_name}")


if __name__ == "__main__":
    app = MainApp()
    app.mainloop()

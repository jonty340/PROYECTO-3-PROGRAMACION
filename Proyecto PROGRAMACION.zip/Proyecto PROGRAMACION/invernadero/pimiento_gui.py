"""
pimiento_gui.py — Monitor del Pimiento — Tema blanco profesional
"""
import tkinter as tk
import sys, os, subprocess

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, BASE_DIR)
from sensor_data import get_manager, RANGOS_OPTIMOS

try:
    import matplotlib; matplotlib.use("TkAgg")
    from matplotlib.figure import Figure
    from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
    HAS_MPL = True
except ImportError:
    HAS_MPL = False

BG     = "#F5F7FA"
BG2    = "#FFFFFF"
BG3    = "#EAEEf3"
BORDER = "#D5DCE6"
ACC    = "#E65100"   # naranja pimiento
ACC_L  = "#FFF3E0"
GREEN  = "#2E7D32"
YELLOW = "#F9A825"
BLUE   = "#1565C0"
RED    = "#D32F2F"
TEXT   = "#1C2833"
TEXT2  = "#5D6D7E"
TDIM   = "#95A5A6"
CULTIVO = "pimiento"

FS = ("Segoe UI", 9)
FB = ("Segoe UI", 9, "bold")


def nivel_color(r):
    if r >= 70: return "#D32F2F", "ALTO"
    if r >= 40: return "#E64A19", "MEDIO"
    return "#2E7D32", "BAJO"


def card(parent, title=None, pady=0):
    outer = tk.Frame(parent, bg=BORDER, padx=1, pady=1)
    outer.pack(fill="x", pady=pady)
    inner = tk.Frame(outer, bg=BG2)
    inner.pack(fill="both", expand=True)
    if title:
        tk.Label(inner, text=title, bg=BG2, fg=TDIM, font=FB).pack(anchor="w", padx=14, pady=(8, 4))
    return inner


def card_expand(parent, title=None):
    outer = tk.Frame(parent, bg=BORDER, padx=1, pady=1)
    outer.pack(fill="both", expand=True)
    inner = tk.Frame(outer, bg=BG2)
    inner.pack(fill="both", expand=True)
    if title:
        tk.Label(inner, text=title, bg=BG2, fg=TDIM, font=FB).pack(anchor="w", padx=14, pady=(8, 4))
    return inner


class PimientoApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("🫑 Monitor de Pimiento")
        self.configure(bg=BG)
        self.state("zoomed")
        self.minsize(1024, 700)
        self.resizable(True, True)
        self.manager = get_manager()
        self._build_ui()
        self._update()

    def _build_ui(self):
        hdr = tk.Frame(self, bg=ACC, height=56)
        hdr.pack(fill="x"); hdr.pack_propagate(False)

        btn_v = tk.Button(hdr, text="⬅ Volver", bg=ACC, fg="white",
                          activebackground=ACC, activeforeground="white",
                          font=FS, relief="flat", cursor="hand2",
                          command=self._volver)
        btn_v.pack(side="left", padx=16)

        tk.Label(hdr, text="🫑  MONITOR DE PIMIENTO",
                 bg=ACC, fg="white", font=("Segoe UI", 18, "bold")).pack(side="left", pady=12)

        self.lbl_estado = tk.Label(hdr, text="● ÓPTIMO",
                                   bg=ACC, fg="#FFCC80", font=("Segoe UI", 12, "bold"))
        self.lbl_estado.pack(side="right", padx=20)

        tk.Frame(self, bg="#E65100", height=2).pack(fill="x")

        body = tk.Frame(self, bg=BG)
        body.pack(fill="both", expand=True, padx=16, pady=12)
        body.columnconfigure(1, weight=1)
        body.rowconfigure(0, weight=1)

        left = tk.Frame(body, bg=BG)
        left.grid(row=0, column=0, sticky="ns", padx=(0, 14))
        self._build_vars(left)
        self._build_recs(left)

        right = tk.Frame(body, bg=BG)
        right.grid(row=0, column=1, sticky="nsew")
        self._build_plagas(right)
        self._build_graph(right)

    def _build_vars(self, p):
        c = card(p, "VALORES ACTUALES vs RANGO ÓPTIMO", pady=(0, 8))
        rangos = RANGOS_OPTIMOS[CULTIVO]
        self.var_w = {}
        for titulo, key, unit, (lo, hi) in [
            ("🌡 Temperatura", "temp",        "°C", rangos["temp"]),
            ("💧 Humedad",     "humedad",     "%",  rangos["humedad"]),
            ("☀ Luminosidad",  "luminosidad", "%",  rangos["luminosidad"]),
        ]:
            row = tk.Frame(c, bg=BG2); row.pack(fill="x", padx=14, pady=5)
            tk.Label(row, text=titulo, bg=BG2, fg=TEXT, font=FB, width=16, anchor="w").pack(side="left")
            vl = tk.Label(row, text="--", bg=BG2, fg=TEXT, font=("Segoe UI", 13, "bold"), width=7, anchor="e")
            vl.pack(side="left")
            tk.Label(row, text=unit, bg=BG2, fg=TEXT2, font=FS).pack(side="left", padx=(2,10))
            tk.Label(row, text=f"Óptimo: {lo}–{hi}{unit}", bg=BG2, fg=TDIM, font=FS).pack(side="left", padx=4)
            ml = tk.Label(row, text="", bg=BG2, fg=GREEN, font=FB); ml.pack(side="left", padx=8)
            self.var_w[key] = (vl, ml)
        tk.Frame(c, bg=BG2, height=4).pack()

    def _build_recs(self, p):
        c = card(p, "RECOMENDACIONES", pady=(0, 8))
        self.rec_text = tk.Text(c, bg=BG3, fg=TEXT, font=("Segoe UI", 9),
                                relief="flat", wrap="word", state="disabled",
                                height=10, bd=0)
        self.rec_text.pack(fill="both", expand=True, padx=12, pady=(0,12))

    def _build_plagas(self, p):
        c = card(p, "🐛  CONTROL DE PLAGAS", pady=(0, 8))
        self.pbars = {}
        for nombre in ["Araña Roja", "Áfidos", "Mancha Bacteriana", "Botrytis"]:
            row = tk.Frame(c, bg=BG2); row.pack(fill="x", padx=14, pady=5)
            tk.Label(row, text=nombre, bg=BG2, fg=TEXT, font=FB, width=18, anchor="w").pack(side="left")
            cv = tk.Canvas(row, height=16, width=220, bg=BG3, highlightthickness=0)
            cv.pack(side="left", padx=6)
            pl = tk.Label(row, text="0%", bg=BG2, fg=TEXT2, font=FS, width=5); pl.pack(side="left")
            nl = tk.Label(row, text="BAJO", bg=BG2, fg=GREEN, font=FB, width=6); nl.pack(side="left", padx=4)
            ib = tk.Button(row, text="ℹ", bg=BG3, fg=TEXT2, relief="flat",
                           font=FS, cursor="hand2", padx=4); ib.pack(side="left")
            self.pbars[nombre] = (cv, pl, nl, ib)
        tk.Frame(c, bg=BG2, height=4).pack()

    def _build_graph(self, p):
        c = card_expand(p, "HISTORIAL EN TIEMPO REAL")
        if not HAS_MPL:
            tk.Label(c, text="Instala matplotlib", bg=BG2, fg=TEXT2).pack(expand=True)
            return
        self.fig = Figure(dpi=92); self.fig.patch.set_facecolor(BG2)
        self.ax = self.fig.add_subplot(111)
        self.ax.set_facecolor(BG3)
        self.ax.tick_params(colors=TEXT2, labelsize=7)
        for sp in self.ax.spines.values(): sp.set_edgecolor(BORDER)
        self.ln_t, = self.ax.plot([], [], color=RED,    lw=1.8, label="Temp °C")
        self.ln_h, = self.ax.plot([], [], color=BLUE,   lw=1.8, label="Humedad %")
        self.ln_l, = self.ax.plot([], [], color=YELLOW, lw=1.8, label="Luz %")
        self.ax.legend(facecolor=BG3, labelcolor=TEXT2, fontsize=7)
        self.fig.tight_layout(pad=1.0)
        cv = FigureCanvasTkAgg(self.fig, master=c)
        cv.draw()
        cv.get_tk_widget().pack(fill="both", expand=True, padx=12, pady=(0,12))
        self.cv = cv

    def _update(self):
        d = self.manager.current
        recs   = self.manager.get_recomendaciones(CULTIVO)
        plagas = self.manager.get_riesgo_plagas(CULTIVO)

        vals = {"temp": d.temperature, "humedad": d.humidity, "luminosidad": d.luminosity}
        for key, (vl, ml) in self.var_w.items():
            v = vals[key]; vl.config(text=f"{v:.1f}")
            rec = recs.get(key, {}); est = rec.get("estado","optimo"); msg = rec.get("msg","")
            col = GREEN if est=="optimo" else (RED if est=="alto" else BLUE)
            vl.config(fg=col); ml.config(text=msg, fg=col)

        gen = recs.get("general","optimo")
        self.lbl_estado.config(
            text={"optimo":"● ÓPTIMO","atencion":"● ATENCIÓN","critico":"● CRÍTICO"}[gen],
            fg={"optimo":"#A5D6A7","atencion":YELLOW,"critico":"#FFCDD2"}[gen])

        self.rec_text.config(state="normal"); self.rec_text.delete("1.0","end")
        lineas = [
            "━━ RECOMENDACIONES — PIMIENTO ━━\n\n",
            f"  🌡 Temperatura:  {d.temperature:.1f}°C  →  {recs['temp']['msg']}\n",
            f"  💧 Humedad:      {d.humidity:.1f}%   →  {recs['humedad']['msg']}\n",
            f"  ☀ Luminosidad:  {d.luminosity:.1f}%   →  {recs['luminosidad']['msg']}\n\n",
            "━━ PREVENCIÓN DE PLAGAS ━━\n\n",
        ]
        hay_plagas = False
        nombres = ["Araña Roja", "Áfidos", "Mancha Bacteriana", "Botrytis"]
        for (nombre, riesgo, desc), key in zip(plagas, nombres):
            if riesgo >= 15:
                rec = desc.split('\n')[-1] if '\n' in desc else desc
                lineas.append(f"  ⚠ {nombre} ({riesgo}%): {rec}\n")
                hay_plagas = True
        if not hay_plagas:
            lineas.append("  ✔ Riesgo controlado. Mantener monitoreo preventivo.\n")
            
        self.rec_text.insert("end","".join(lineas))
        self.rec_text.config(state="disabled")

        nombres = ["Araña Roja", "Áfidos", "Mancha Bacteriana", "Botrytis"]
        for (nombre, riesgo, desc), key in zip(plagas, nombres):
            if key not in self.pbars: continue
            cv, pl, nl, ib = self.pbars[key]
            col, nivel = nivel_color(riesgo)
            cv.delete("all")
            w = int(220 * riesgo / 100)
            if w > 0: cv.create_rectangle(0,0,w,16,fill=col,outline="")
            cv.create_text(110, 8, text=f"{riesgo}%", fill="white", font=FB)
            pl.config(text=f"{riesgo}%"); nl.config(text=nivel, fg=col)
            ib.config(command=lambda d=desc, n=nombre: self._info(n, d))

        if HAS_MPL:
            th = list(self.manager.history["temperature"])
            hh = list(self.manager.history["humidity"])
            lh = list(self.manager.history["luminosity"])
            x  = list(range(len(th)))
            self.ln_t.set_data(x, th); self.ln_h.set_data(x, hh); self.ln_l.set_data(x, lh)
            av = th+hh+lh
            if av:
                mn,mx=min(av),max(av); mg=max(2,(mx-mn)*0.15)
                self.ax.set_xlim(0,max(60,len(x))); self.ax.set_ylim(mn-mg,mx+mg)
            self.cv.draw_idle()

        self.after(1000, self._update)

    def _info(self, nombre, desc):
        w = tk.Toplevel(self); w.title(f"ℹ {nombre}")
        w.configure(bg=BG2); w.geometry("420x200"); w.resizable(False,False)
        tk.Frame(w, bg=ACC, height=4).pack(fill="x")
        tk.Label(w, text=f"🐛  {nombre}", bg=BG2, fg=ACC, font=("Segoe UI",13,"bold")).pack(pady=(16,8))
        tk.Label(w, text=desc, bg=BG2, fg=TEXT, font=FS, wraplength=380, justify="left").pack(padx=20)
        tk.Button(w, text="Cerrar", bg=ACC, fg="white", relief="flat",
                  font=FB, command=w.destroy).pack(pady=16)

    def _volver(self):
        path = os.path.join(BASE_DIR, "main_gui.py")
        if os.path.exists(path): subprocess.Popen([sys.executable, path])
        self.destroy()


if __name__ == "__main__":
    PimientoApp().mainloop()

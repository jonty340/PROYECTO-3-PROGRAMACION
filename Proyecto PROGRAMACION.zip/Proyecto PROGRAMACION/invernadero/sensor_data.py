"""
sensor_data.py — Módulo de Sensores del Invernadero
Simula datos en tiempo real de temperatura, humedad y luminosidad.
Obtiene la hora de Colombia y temperatura exterior real via Open-Meteo.
"""

import threading
import time
import random
import math
import json
import os
from datetime import datetime
from collections import deque

try:
    import pytz
    HAS_PYTZ = True
except ImportError:
    HAS_PYTZ = False

try:
    import requests
    HAS_REQUESTS = True
except ImportError:
    HAS_REQUESTS = False

# ─── Rangos óptimos por cultivo ─────────────────────────────────────────────
RANGOS_OPTIMOS = {
    "tomate": {
        "temp":      (18.0, 27.0),
        "humedad":   (65.0, 85.0),
        "luminosidad": (70.0, 90.0),
    },
    "lechuga": {
        "temp":      (15.0, 20.0),
        "humedad":   (60.0, 70.0),
        "luminosidad": (50.0, 75.0),
    },
    "pimiento": {
        "temp":      (20.0, 30.0),
        "humedad":   (60.0, 80.0),
        "luminosidad": (65.0, 85.0),
    },
}

# ─── Plagas por cultivo ──────────────────────────────────────────────────────
PLAGAS = {
    "tomate": [
        ("Araña Roja",      "arana_roja",   "Alta temperatura y baja humedad favorecen su aparición.\nRevisar el envés de las hojas. Aplicar acaricida si es necesario."),
        ("Áfidos",          "afidos",       "Prefieren brotes tiernos. Alta humedad los favorece.\nUsar jabón potásico o insecticida sistémico."),
        ("Mosca Blanca",    "mosca_blanca", "Alta temperatura facilita su reproducción.\nColocar trampas amarillas y controlar con insecticida."),
        ("Tizón Tardío",    "tizon",        "Hongo favorecido por alta humedad y temperaturas frescas.\nMejorar ventilación y aplicar fungicida cúprico."),
    ],
    "lechuga": [
        ("Áfidos",          "afidos",       "Prefieren hojas internas. Revisar frecuentemente.\nUsar jabón potásico o extracto de ajo."),
        ("Babosas",         "babosas",      "Alta humedad y temperaturas bajas las activan.\nUsar cebos ecológicos y reducir humedad en suelo."),
        ("Mildiu Velloso",  "mildiu",       "Hongo que aparece con alta humedad y temperatura fresca.\nMejorar ventilación, evitar mojar las hojas."),
        ("Podredumbre Gris","podredumbre",  "Botrytis favorecida por humedad >80%.\nEliminar hojas afectadas y aplicar fungicida."),
    ],
    "pimiento": [
        ("Araña Roja",      "arana_roja",   "Baja humedad y alta temperatura son factores de riesgo.\nMantener humedad adecuada y usar acaricidas si es necesario."),
        ("Áfidos",          "afidos",       "Transmiten virus entre plantas. Revisar semanalmente.\nUsar insecticidas o enemigos naturales como la mariquita."),
        ("Mancha Bacteriana","mancha_bact", "Alta humedad + temperatura cálida favorecen la bacteria.\nEvitar mojar el follaje. Aplicar cobre preventivamente."),
        ("Botrytis",        "botrytis",     "Alta humedad y temperatura moderada-alta la favorecen.\nMejorar aireación y retirar tejidos afectados."),
    ],
}


class SensorData:
    """Contenedor de una lectura de sensores."""
    def __init__(self):
        self.temperature  = 24.5
        self.humidity     = 72.0
        self.luminosity   = 68.0
        self.exterior_temp = 18.0
        self.timestamp    = datetime.now()


class SensorManager:
    """Administra la simulación de sensores del invernadero."""

    HISTORY_SIZE = 60
    CONFIG_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "config.json")

    def __init__(self, base_temp=24.5, base_humidity=72.0, base_luminosity=68.0):
        self.current = SensorData()
        self.history = {
            "temperature":  deque(maxlen=self.HISTORY_SIZE),
            "humidity":     deque(maxlen=self.HISTORY_SIZE),
            "luminosity":   deque(maxlen=self.HISTORY_SIZE),
            "timestamps":   deque(maxlen=self.HISTORY_SIZE),
        }
        self._base_temp       = base_temp
        self._base_humidity   = base_humidity
        self._base_luminosity = base_luminosity
        
        # Cargar configuración si existe
        try:
            if os.path.exists(self.CONFIG_FILE):
                with open(self.CONFIG_FILE, "r") as f:
                    cfg = json.load(f)
                    self._base_temp = cfg.get("temp", base_temp)
                    self._base_humidity = cfg.get("hum", base_humidity)
                    self._base_luminosity = cfg.get("lum", base_luminosity)
        except Exception:
            pass
        self._time_offset = 0
        self._running  = False
        self._thread   = None
        self._ext_thread = None
        self._callbacks = []

        if HAS_PYTZ:
            self._colombia_tz = pytz.timezone("America/Bogota")
        else:
            self._colombia_tz = None

        # Pre-cargar historial
        for _ in range(self.HISTORY_SIZE):
            self._simulate_step()

    # ── Tiempo Colombia ──────────────────────────────────────────────────────
    def get_colombia_time(self) -> datetime:
        if HAS_PYTZ and self._colombia_tz:
            return datetime.now(self._colombia_tz)
        return datetime.now()

    def get_colombia_time_str(self) -> str:
        return self.get_colombia_time().strftime("%H:%M:%S")

    def get_colombia_date_str(self) -> str:
        meses = ["Enero","Febrero","Marzo","Abril","Mayo","Junio",
                 "Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre"]
        dt = self.get_colombia_time()
        return f"{dt.day} de {meses[dt.month - 1]} de {dt.year}"

    # ── Temperatura exterior real ─────────────────────────────────────────────
    def _fetch_exterior_temp(self) -> float:
        if not HAS_REQUESTS:
            return round(18.0 + random.uniform(-3, 3), 1)
        try:
            url = (
                "https://api.open-meteo.com/v1/forecast"
                "?latitude=4.711&longitude=-74.0721"
                "&current=temperature_2m"
                "&timezone=America%2FBogota"
            )
            resp = requests.get(url, timeout=4)
            if resp.status_code == 200:
                return resp.json()["current"]["temperature_2m"]
        except Exception:
            pass
        return round(18.0 + random.uniform(-3, 3), 1)

    def _update_exterior_loop(self):
        self.current.exterior_temp = self._fetch_exterior_temp()
        while self._running:
            time.sleep(300)
            self.current.exterior_temp = self._fetch_exterior_temp()

    # ── Simulación ───────────────────────────────────────────────────────────
    def set_manual_values(self, temp, hum, lum):
        self._base_temp = temp
        self._base_humidity = hum
        self._base_luminosity = lum
        try:
            with open(self.CONFIG_FILE, "w") as f:
                json.dump({"temp": temp, "hum": hum, "lum": lum}, f)
        except Exception:
            pass

    def _simulate_step(self):
        self._time_offset += 1
        
        # Valores controlados manualmente con un micro ruido para que las gráficas no sean totalmente planas
        temp = self._base_temp + random.gauss(0, 0.1)
        hum = min(100.0, max(0.0, self._base_humidity + random.gauss(0, 0.15)))
        lum = min(100.0, max(0.0, self._base_luminosity + random.gauss(0, 0.2)))

        self.current.temperature  = round(temp, 1)
        self.current.humidity     = round(hum, 1)
        self.current.luminosity   = round(lum, 1)

        if self._colombia_tz and HAS_PYTZ:
            self.current.timestamp = datetime.now(self._colombia_tz)
        else:
            self.current.timestamp = datetime.now()

        self.history["temperature"].append(self.current.temperature)
        self.history["humidity"].append(self.current.humidity)
        self.history["luminosity"].append(self.current.luminosity)
        self.history["timestamps"].append(self.current.timestamp.strftime("%H:%M:%S"))

    # ── Estadísticas ─────────────────────────────────────────────────────────
    def get_stats(self, variable: str) -> dict:
        data = list(self.history[variable])
        if len(data) < 2:
            return {"mean": 0, "std": 0, "min": 0, "max": 0, "trend": "estable", "slope": 0}

        n = len(data)
        mean = sum(data) / n
        std  = math.sqrt(sum((x - mean) ** 2 for x in data) / n)
        x_mean = (n - 1) / 2.0
        num = sum((i - x_mean) * (data[i] - mean) for i in range(n))
        den = sum((i - x_mean) ** 2 for i in range(n))
        slope = num / den if den != 0 else 0
        trend = "⬆ Subiendo" if slope > 0.05 else "⬇ Bajando" if slope < -0.05 else "➡ Estable"

        return {
            "mean":  round(mean, 2),
            "std":   round(std, 2),
            "min":   round(min(data), 2),
            "max":   round(max(data), 2),
            "trend": trend,
            "slope": round(slope, 4),
        }

    # ── Recomendaciones ──────────────────────────────────────────────────────
    def get_recomendaciones(self, cultivo: str) -> dict:
        rangos = RANGOS_OPTIMOS.get(cultivo, {})
        temp  = self.current.temperature
        hum   = self.current.humidity
        lum   = self.current.luminosity
        resultado = {}

        for var, val, llave in [("temp", temp, "temp"), ("humedad", hum, "humedad"), ("luminosidad", lum, "luminosidad")]:
            lo, hi = rangos.get(var, (0, 100))
            if val < lo:
                delta = round(lo - val, 1)
                estado = "bajo"
                msg = f"⬆ Subir {delta:.1f} unidades"
            elif val > hi:
                delta = round(val - hi, 1)
                estado = "alto"
                msg = f"⬇ Bajar {delta:.1f} unidades"
            else:
                delta = 0
                estado = "optimo"
                msg = "✔ En rango óptimo"
            resultado[llave] = {"delta": delta, "estado": estado, "msg": msg, "lo": lo, "hi": hi, "val": val}

        estados = [v["estado"] for v in resultado.values()]
        if "alto" in estados or "bajo" in estados:
            altos  = sum(1 for e in estados if e == "alto")
            bajos  = sum(1 for e in estados if e == "bajo")
            resultado["general"] = "critico" if (altos + bajos) >= 2 else "atencion"
        else:
            resultado["general"] = "optimo"

        return resultado

    # ── Riesgo de plagas ─────────────────────────────────────────────────────
    def get_riesgo_plagas(self, cultivo: str) -> list:
        temp = self.current.temperature
        hum  = self.current.humidity
        resultados = []

        if cultivo == "tomate":
            r_arana = max(0, min(100, int((temp - 22) * 5 + (70 - hum) * 1.2)))
            r_afidos = max(0, min(100, int((hum - 65) * 1.5 + (25 - temp) * 2)))
            r_mosca  = max(0, min(100, int((temp - 24) * 4.5 + (hum - 60) * 0.5)))
            r_tizon  = max(0, min(100, int((hum - 75) * 2.5 + (22 - temp) * 1.5)))
            resultados = [
                ("Araña Roja",       r_arana,  PLAGAS["tomate"][0][2]),
                ("Áfidos",           r_afidos, PLAGAS["tomate"][1][2]),
                ("Mosca Blanca",     r_mosca,  PLAGAS["tomate"][2][2]),
                ("Tizón Tardío",     r_tizon,  PLAGAS["tomate"][3][2]),
            ]
        elif cultivo == "lechuga":
            r_afidos  = max(0, min(100, int((hum - 60) * 1.0 + (22 - temp) * 1.5)))
            r_babosas = max(0, min(100, int((hum - 65) * 2.0 + (20 - temp) * 1.0)))
            r_mildiu  = max(0, min(100, int((hum - 70) * 2.5 + (20 - temp) * 0.8)))
            r_podred  = max(0, min(100, int((hum - 75) * 3.0)))
            resultados = [
                ("Áfidos",           r_afidos,  PLAGAS["lechuga"][0][2]),
                ("Babosas",          r_babosas, PLAGAS["lechuga"][1][2]),
                ("Mildiu Velloso",   r_mildiu,  PLAGAS["lechuga"][2][2]),
                ("Podredumbre Gris", r_podred,  PLAGAS["lechuga"][3][2]),
            ]
        elif cultivo == "pimiento":
            r_arana  = max(0, min(100, int((temp - 24) * 5 + (65 - hum) * 1.2)))
            r_afidos = max(0, min(100, int((hum - 60) * 1.0 + (25 - temp) * 1.2)))
            r_mancha = max(0, min(100, int((hum - 65) * 1.8 + (temp - 22) * 1.5)))
            r_botry  = max(0, min(100, int((hum - 70) * 2.0 + (temp - 20) * 0.8)))
            resultados = [
                ("Araña Roja",        r_arana,  PLAGAS["pimiento"][0][2]),
                ("Áfidos",            r_afidos, PLAGAS["pimiento"][1][2]),
                ("Mancha Bacteriana", r_mancha, PLAGAS["pimiento"][2][2]),
                ("Botrytis",          r_botry,  PLAGAS["pimiento"][3][2]),
            ]

        # Normalizar a 0-100
        resultados = [(n, max(0, min(100, r)), d) for n, r, d in resultados]
        return resultados

    # ── Lifecycle ────────────────────────────────────────────────────────────
    def start(self):
        self._running = True
        self._thread = threading.Thread(target=self._loop, daemon=True)
        self._thread.start()
        self._ext_thread = threading.Thread(target=self._update_exterior_loop, daemon=True)
        self._ext_thread.start()

    def _loop(self):
        while self._running:
            self._simulate_step()
            for cb in list(self._callbacks):
                try:
                    cb(self.current)
                except Exception:
                    pass
            time.sleep(1)

    def stop(self):
        self._running = False

    def add_callback(self, func):
        self._callbacks.append(func)

    def remove_callback(self, func):
        if func in self._callbacks:
            self._callbacks.remove(func)


# ── Singleton global ─────────────────────────────────────────────────────────
_manager: SensorManager | None = None

def get_manager(base_temp=24.5, base_humidity=72.0, base_luminosity=68.0) -> SensorManager:
    global _manager
    if _manager is None:
        _manager = SensorManager(base_temp, base_humidity, base_luminosity)
        _manager.start()
    return _manager

# 🌿 Sistema de Invernadero Inteligente

Sistema de monitoreo y control para cultivos de **tomate, lechuga y pimiento**.
Sensores simulados en tiempo real, interfaz gráfica en **Python/Tkinter** y
matemática en **C++**.

---

## 📁 Estructura del Proyecto

```
invernadero/
├── main_gui.py           ← Dashboard principal (EJECUTAR ESTE)
├── tomate_gui.py         ← Monitor del tomate
├── lechuga_gui.py        ← Monitor de la lechuga
├── pimiento_gui.py       ← Monitor del pimiento
├── general_gui.py        ← Condiciones generales
├── sensor_data.py        ← Motor de sensores simulados
├── requirements.txt      ← Dependencias Python
├── instalar.bat          ← Instalador automático
└── cpp/
    ├── matematica.h      ← Cabeceras C++
    ├── matematica.cpp    ← Estadísticas y tendencias
    ├── recomendaciones.cpp ← Motor de recomendaciones
    ├── plagas.cpp        ← Riesgo de plagas
    ├── graficas.cpp      ← Suavizado de datos
    └── compile.bat       ← Compilador automático
```

---

## 🚀 Instrucciones de Uso

### Paso 1 — Instalar dependencias Python
```
Doble clic en: instalar.bat
```

### Paso 2 — Compilar módulos C++
```
Entrar a la carpeta cpp\
Doble clic en: compile.bat
```

### Paso 3 — Ejecutar el sistema
```
python main_gui.py
```

---

## 🎛️ Funcionalidades

| Pantalla           | Descripción |
|--------------------|-------------|
| `main_gui.py`      | Dashboard con gauges, gráficas en tiempo real, hora Colombia y temperatura exterior |
| `tomate_gui.py`    | Recomendaciones + barras de riesgo de plagas para el tomate |
| `lechuga_gui.py`   | Igual pero para la lechuga |
| `pimiento_gui.py`  | Igual pero para el pimiento |
| `general_gui.py`   | Zona de equilibrio para conservar los 3 cultivos juntos |

---

## 🌡️ Rangos Óptimos

| Variable      | Tomate     | Lechuga    | Pimiento   |
|---------------|------------|------------|------------|
| Temperatura   | 18–27 °C   | 15–20 °C   | 20–30 °C   |
| Humedad       | 65–85 %    | 60–70 %    | 60–80 %    |
| Luminosidad   | 70–90 %    | 50–75 %    | 65–85 %    |

---

## 🔧 Uso de los ejecutables C++

```bash
# Estadísticas de una serie de valores
matematica.exe "24.5,24.8,25.1,24.3,23.9"

# Recomendaciones para un cultivo
recomendaciones.exe tomate 28.5 70.0 85.0

# Riesgo de plagas
plagas.exe tomate 29.0 88.0

# Suavizado de datos para gráficas
graficas.exe "24.5,24.8,25.1" 3
```

---

## 📡 API de Clima

El sistema consulta **Open-Meteo** (gratuito, sin API key) para obtener
la temperatura exterior real de Bogotá, Colombia en tiempo real.
Si no hay internet, usa un valor simulado.

---

## 🕐 Hora Colombia

Toda la interfaz muestra la hora en zona horaria **America/Bogota (UTC-5)**
usando la librería `pytz`.

"""
general_gui.py — Dashboard General / Punto de Equilibrio — Tema blanco profesional
"""
import tkinter as tk
import sys, os, subprocess

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, BASE_DIR)
from sensor_data import get_manager, RANGOS_OPTIMOS

BG     = "#F5F7FA"
BG2    = "#FFFFFF"
BG3    = "#EAEEf3"
BORDER = "#D5DCE6"
ACC    = "#1565C0"   # azul general
ACC_L  = "#E3F2FD"
GREEN  = "#2E7D32"
YELLOW = "#F9A825"
BLUE   = "#1565C0"
RED    = "#D32F2F"
TEXT   = "#1C2833"
TEXT2  = "#5D6D7E"
TDIM   = "#95A5A6"

FS = ("Segoe UI", 9)
FB = ("Segoe UI", 9, "bold")


def card(parent, title=None, pady=0):
    outer = tk.Frame(parent, bg=BORDER, padx=1, pady=1)
    outer.pack(fill="x", pady=pady)
    inner = tk.Frame(outer, bg=BG2)
    inner.pack(fill="both", expand=True)
    if title:
        tk.Label(inner, text=title, bg=BG2, fg=TDIM, font=FB).pack(anchor="w", padx=14, pady=(8, 4))
    return inner


class GeneralApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("⚙ Panel de Control General")
        self.configure(bg=BG)
        self.state("zoomed")
        self.minsize(1024, 700)
        self.resizable(True, True)
        self.manager = get_manager()
        self._build_ui()
        self._update()

    def _build_ui(self):
        hdr = tk.Frame(self, bg=ACC, height=56)
        hdr.pack(fill="x"); hdr.pack_propagate(False)

        btn_v = tk.Button(hdr, text="⬅ Volver", bg=ACC, fg="white",
                          activebackground=ACC, activeforeground="white",
                          font=FS, relief="flat", cursor="hand2",
                          command=self._volver)
        btn_v.pack(side="left", padx=16)

        tk.Label(hdr, text="⚙  PANEL DE CONTROL GENERAL",
                 bg=ACC, fg="white", font=("Segoe UI", 18, "bold")).pack(side="left", pady=12)

        self.lbl_hora = tk.Label(hdr, text="", bg=ACC, fg="#BBDEFB", font=("Segoe UI", 13, "bold"))
        self.lbl_hora.pack(side="right", padx=20)

        tk.Frame(self, bg="#0D47A1", height=2).pack(fill="x")

        body = tk.Frame(self, bg=BG)
        body.pack(fill="both", expand=True, padx=16, pady=12)
        
        # Grid para el body (2 filas, 1 columna, peso en la de abajo)
        body.columnconfigure(0, weight=1)
        body.rowconfigure(1, weight=1)

        top = tk.Frame(body, bg=BG)
        top.grid(row=0, column=0, sticky="ew", pady=(0, 14))
        self._build_vars(top)

        bot = tk.Frame(body, bg=BG)
        bot.grid(row=1, column=0, sticky="nsew")
        self._build_analisis(bot)

    def _build_vars(self, p):
        c = card(p, "MONITOREO GLOBAL (Equilibrio para Tomate, Lechuga y Pimiento)")
        row = tk.Frame(c, bg=BG2); row.pack(fill="x", padx=14, pady=(0,14))

        self.w_vars = {}
        for titulo, key, unit in [
            ("🌡 Temperatura", "temp",        "°C"),
            ("💧 Humedad",     "humedad",     "%"),
            ("☀ Luminosidad",  "luminosidad", "%")
        ]:
            col = tk.Frame(row, bg=BG3, padx=16, pady=10)
            col.pack(side="left", expand=True, fill="x", padx=6)
            tk.Label(col, text=titulo, bg=BG3, fg=TEXT2, font=FB).pack()
            lb = tk.Label(col, text="--", bg=BG3, fg=TEXT, font=("Segoe UI", 16, "bold"))
            lb.pack(pady=4)
            st = tk.Label(col, text="", bg=BG3, fg=TEXT2, font=FS)
            st.pack()
            self.w_vars[key] = (lb, st)

    def _build_analisis(self, p):
        c = card(p, "ANÁLISIS DE INTERSECCIÓN (RANGOS)")
        self.txt = tk.Text(c, bg=BG3, fg=TEXT, font=("Segoe UI", 10),
                           relief="flat", wrap="word", state="disabled", bd=0)
        self.txt.pack(fill="both", expand=True, padx=14, pady=(0,14))

    def _get_interseccion(self, variable):
        mmax = max(RANGOS_OPTIMOS["tomate"][variable][0],
                   RANGOS_OPTIMOS["lechuga"][variable][0],
                   RANGOS_OPTIMOS["pimiento"][variable][0])
        mmin = min(RANGOS_OPTIMOS["tomate"][variable][1],
                   RANGOS_OPTIMOS["lechuga"][variable][1],
                   RANGOS_OPTIMOS["pimiento"][variable][1])
        return (mmax, mmin) if mmax <= mmin else None

    def _update(self):
        d = self.manager.current
        self.lbl_hora.config(text=f"Bogotá: {self.manager.get_colombia_time_str()}")

        v_map = {"temp": d.temperature, "humedad": d.humidity, "luminosidad": d.luminosity}
        u_map = {"temp": "°C", "humedad": "%", "luminosidad": "%"}

        lineas = ["━━ ESTADO DEL EQUILIBRIO ENTRE CULTIVOS ━━\n\n"]
        for key, (lb, st) in self.w_vars.items():
            val = v_map[key]
            lb.config(text=f"{val:.1f} {u_map[key]}")
            
            inter = self._get_interseccion(key)
            if inter:
                l, h = inter
                if l <= val <= h:
                    st.config(text=f"En punto óptimo general ({l}-{h})", fg=GREEN)
                    lb.config(fg=GREEN)
                    lineas.append(f"✔ {key.upper()}: Excelente. Funciona para los 3 cultivos.\n")
                else:
                    st.config(text=f"Fuera de equilibrio (Ideal: {l}-{h})", fg=RED)
                    lb.config(fg=RED)
                    lineas.append(f"⚠ {key.upper()}: Ajustar hacia {l}-{h}{u_map[key]} para beneficiar a todos.\n")
            else:
                st.config(text="No hay un rango óptimo que cubra a los 3", fg=ORANGE)
                lb.config(fg=ORANGE)
                lineas.append(f"⚠ {key.upper()}: Imposible satisfacer a los 3 simultáneamente.\n")

        self.txt.config(state="normal")
        self.txt.delete("1.0", "end")
        self.txt.insert("end", "".join(lineas))
        self.txt.config(state="disabled")

        self.after(1000, self._update)

    def _volver(self):
        path = os.path.join(BASE_DIR, "main_gui.py")
        if os.path.exists(path): subprocess.Popen([sys.executable, path])
        self.destroy()

if __name__ == "__main__":
    GeneralApp().mainloop()

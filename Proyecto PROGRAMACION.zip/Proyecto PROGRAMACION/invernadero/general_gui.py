"""
general_gui.py — Ventana de Condiciones Generales
Muestra condiciones óptimas de equilibrio para los 3 cultivos juntos.
"""

import tkinter as tk
import sys, os

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, BASE_DIR)

from sensor_data import get_manager, RANGOS_OPTIMOS

try:
    import matplotlib
    matplotlib.use("TkAgg")
    from matplotlib.figure import Figure
    from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
    HAS_MPL = True
except ImportError:
    HAS_MPL = False

BG      = "#0a0a1a"
BG2     = "#141428"
BG3     = "#1e1e3a"
ACCENT  = "#7986CB"
GREEN   = "#4CAF50"
YELLOW  = "#FFD54F"
RED     = "#EF5350"
BLUE    = "#42A5F5"
TEXT    = "#E8EAF6"
TEXT2   = "#9FA8DA"
TEXT_DIM = "#3a3a6a"

# Condiciones de equilibrio para los 3 cultivos
EQUILIBRIO = {
    "temp":        (18.0, 27.0, "°C"),
    "humedad":     (62.0, 78.0, "%"),
    "luminosidad": (60.0, 80.0, "%"),
}

CULTIVOS_INFO = {
    "tomate":  ("🍅 Tomate",   "#e53935", (18, 27), (65, 85), (70, 90)),
    "lechuga": ("🥬 Lechuga",  "#4CAF50", (15, 20), (60, 70), (50, 75)),
    "pimiento":("🫑 Pimiento", "#FF7043", (20, 30), (60, 80), (65, 85)),
}


class GeneralApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("⚙ Condiciones Generales del Invernadero")
        self.configure(bg=BG)
        self.geometry("1000x700")
        self.resizable(True, True)
        self.manager = get_manager()
        self._build_ui()
        self._update()

    def _build_ui(self):
        hdr = tk.Frame(self, bg="#1a1a4a", height=60)
        hdr.pack(fill="x")
        hdr.pack_propagate(False)
        btn_volver = tk.Button(hdr, text="⬅ Volver", bg="#0a0a1a", fg=TEXT, font=("Segoe UI", 10, "bold"),
                               relief="flat", cursor="hand2", command=self._volver)
        btn_volver.pack(side="left", padx=(20, 0))
        tk.Label(hdr, text="⚙  PANEL DE CONTROL GENERAL",
                 bg="#1a1a4a", fg=TEXT, font=("Segoe UI", 20, "bold")).pack(side="left", padx=20, pady=8)
        self.lbl_hora = tk.Label(hdr, text="", bg="#1a1a4a", fg=YELLOW,
                                  font=("Segoe UI", 13, "bold"))
        self.lbl_hora.pack(side="right", padx=20)

        body = tk.Frame(self, bg=BG)
        body.pack(fill="both", expand=True, padx=12, pady=10)

        # Fila superior: sensores actuales
        self._build_current_sensors(body)
        # Tabla de rangos por cultivo
        self._build_ranges_table(body)
        # Recomendación de equilibrio
        self._build_equilibrio(body)
        # Gráfica
        self._build_graph(body)

    def _build_current_sensors(self, parent):
        frame = tk.LabelFrame(parent, text="  SENSORES ACTUALES  ",
                              bg=BG2, fg=TEXT2, font=("Segoe UI", 10, "bold"), bd=1)
        frame.pack(fill="x", pady=(0, 8))
        row = tk.Frame(frame, bg=BG2)
        row.pack(pady=10)
        self.sens_labels = {}
        for icon, key, unit in [("🌡", "temp", "°C"), ("💧", "hum", "%"), ("☀", "lum", "%")]:
            col = tk.Frame(row, bg=BG3, padx=18, pady=10)
            col.pack(side="left", padx=8)
            tk.Label(col, text=icon, bg=BG3, fg=TEXT, font=("Segoe UI", 18)).pack()
            lbl = tk.Label(col, text="--", bg=BG3, fg=ACCENT,
                           font=("Segoe UI", 20, "bold"))
            lbl.pack()
            tk.Label(col, text=unit, bg=BG3, fg=TEXT2, font=("Segoe UI", 10)).pack()
            self.sens_labels[key] = lbl

    def _build_ranges_table(self, parent):
        frame = tk.LabelFrame(parent, text="  RANGOS ÓPTIMOS POR CULTIVO  ",
                              bg=BG2, fg=TEXT2, font=("Segoe UI", 10, "bold"), bd=1)
        frame.pack(fill="x", pady=(0, 8))

        header = tk.Frame(frame, bg=BG3)
        header.pack(fill="x", padx=8, pady=(6, 2))
        for txt, w in [("Cultivo", 16), ("Temperatura", 18), ("Humedad", 18), ("Luminosidad", 18), ("Estado", 12)]:
            tk.Label(header, text=txt, bg=BG3, fg=TEXT2,
                     font=("Segoe UI", 9, "bold"), width=w, anchor="center").pack(side="left", padx=2)

        self.table_labels = {}
        for cultivo, (nombre, color, tr, hr, lr) in CULTIVOS_INFO.items():
            row = tk.Frame(frame, bg=BG2)
            row.pack(fill="x", padx=8, pady=2)
            tk.Label(row, text=nombre, bg=BG2, fg=color,
                     font=("Segoe UI", 10, "bold"), width=16, anchor="w").pack(side="left", padx=2)
            tk.Label(row, text=f"{tr[0]}–{tr[1]} °C", bg=BG2, fg=TEXT,
                     font=("Segoe UI", 9), width=18, anchor="center").pack(side="left", padx=2)
            tk.Label(row, text=f"{hr[0]}–{hr[1]} %", bg=BG2, fg=TEXT,
                     font=("Segoe UI", 9), width=18, anchor="center").pack(side="left", padx=2)
            tk.Label(row, text=f"{lr[0]}–{lr[1]} %", bg=BG2, fg=TEXT,
                     font=("Segoe UI", 9), width=18, anchor="center").pack(side="left", padx=2)
            estado_lbl = tk.Label(row, text="●", bg=BG2, fg=GREEN,
                                  font=("Segoe UI", 12, "bold"), width=12, anchor="center")
            estado_lbl.pack(side="left", padx=2)
            self.table_labels[cultivo] = estado_lbl

    def _build_equilibrio(self, parent):
        frame = tk.LabelFrame(parent, text="  ZONA DE EQUILIBRIO (Todos los cultivos)  ",
                              bg=BG2, fg=TEXT2, font=("Segoe UI", 10, "bold"), bd=1)
        frame.pack(fill="x", pady=(0, 8))

        self.eq_text = tk.Text(frame, bg=BG3, fg=TEXT, font=("Segoe UI", 10),
                               relief="flat", wrap="word", state="disabled", height=5)
        self.eq_text.pack(fill="x", padx=8, pady=8)

    def _build_graph(self, parent):
        frame = tk.LabelFrame(parent, text="  GRÁFICA HISTÓRICA (60 seg)  ",
                              bg=BG2, fg=TEXT2, font=("Segoe UI", 10, "bold"), bd=1)
        frame.pack(fill="both", expand=True)
        if not HAS_MPL:
            tk.Label(frame, text="Instala matplotlib", bg=BG2, fg=YELLOW).pack(expand=True)
            return
        self.fig = Figure(figsize=(7, 2.5), dpi=90)
        self.fig.patch.set_facecolor(BG2)
        self.ax = self.fig.add_subplot(111)
        self.ax.set_facecolor(BG3)
        self.ax.tick_params(colors=TEXT2, labelsize=7)
        for sp in self.ax.spines.values():
            sp.set_edgecolor(TEXT_DIM)
        self.line_t, = self.ax.plot([], [], color="#EF5350", linewidth=1.5, label="Temp °C")
        self.line_h, = self.ax.plot([], [], color=BLUE,     linewidth=1.5, label="Humedad %")
        self.line_l, = self.ax.plot([], [], color=YELLOW,   linewidth=1.5, label="Luz %")
        # Zona de equilibrio
        lo_t, hi_t, _ = EQUILIBRIO["temp"]
        self.ax.axhspan(lo_t, hi_t, alpha=0.08, color=GREEN)
        self.ax.legend(facecolor=BG3, labelcolor=TEXT2, fontsize=7)
        self.fig.tight_layout(pad=1.0)
        cv = FigureCanvasTkAgg(self.fig, master=frame)
        cv.draw()
        cv.get_tk_widget().pack(fill="both", expand=True, padx=6, pady=6)
        self.cv = cv

    def _update(self):
        data = self.manager.current

        # Hora Colombia
        self.lbl_hora.config(text=f"🕐 {self.manager.get_colombia_time_str()}  Colombia")

        # Sensores
        self.sens_labels["temp"].config(text=f"{data.temperature:.1f} °C")
        self.sens_labels["hum"].config(text=f"{data.humidity:.1f} %")
        self.sens_labels["lum"].config(text=f"{data.luminosity:.1f} %")

        # Estado por cultivo
        for cultivo, (_, color, tr, hr, lr) in CULTIVOS_INFO.items():
            t_ok = tr[0] <= data.temperature <= tr[1]
            h_ok = hr[0] <= data.humidity    <= hr[1]
            l_ok = lr[0] <= data.luminosity  <= lr[1]
            if t_ok and h_ok and l_ok:
                self.table_labels[cultivo].config(text="● ÓPTIMO",  fg=GREEN)
            elif (not t_ok) and (not h_ok):
                self.table_labels[cultivo].config(text="● CRÍTICO", fg=RED)
            else:
                self.table_labels[cultivo].config(text="● ATENCIÓN", fg=YELLOW)

        # Texto de equilibrio
        self.eq_text.config(state="normal")
        self.eq_text.delete("1.0", "end")
        lo_t, hi_t, _ = EQUILIBRIO["temp"]
        lo_h, hi_h, _ = EQUILIBRIO["humedad"]
        lo_l, hi_l, _ = EQUILIBRIO["luminosidad"]
        lineas = [
            "  La zona de equilibrio permite conservar los 3 cultivos simultáneamente:\n\n",
            f"  🌡 Temperatura:  {lo_t}–{hi_t} °C   →  Actual: {data.temperature:.1f}°C  ",
            "✔ OK\n" if lo_t <= data.temperature <= hi_t else "⚠ FUERA DE RANGO\n",
            f"  💧 Humedad:      {lo_h}–{hi_h} %    →  Actual: {data.humidity:.1f}%   ",
            "✔ OK\n" if lo_h <= data.humidity <= hi_h else "⚠ FUERA DE RANGO\n",
            f"  ☀ Luminosidad:  {lo_l}–{lo_l} %    →  Actual: {data.luminosity:.1f}%   ",
            "✔ OK\n" if lo_l <= data.luminosity <= hi_l else "⚠ FUERA DE RANGO\n",
        ]
        self.eq_text.insert("end", "".join(lineas))
        self.eq_text.config(state="disabled")

        # Gráfica
        if HAS_MPL:
            t_h = list(self.manager.history["temperature"])
            h_h = list(self.manager.history["humidity"])
            l_h = list(self.manager.history["luminosity"])
            x   = list(range(len(t_h)))
            self.line_t.set_data(x, t_h)
            self.line_h.set_data(x, h_h)
            self.line_l.set_data(x, l_h)
            all_vals = t_h + h_h + l_h
            if all_vals:
                mn, mx = min(all_vals), max(all_vals)
                self.ax.set_xlim(0, max(60, len(x)))
                self.ax.set_ylim(mn - 5, mx + 5)
            self.cv.draw_idle()

        self.after(1000, self._update)

    def _volver(self):
        import subprocess
        script_path = os.path.join(BASE_DIR, "main_gui.py")
        if os.path.exists(script_path):
            subprocess.Popen([sys.executable, script_path])
        self.destroy()

if __name__ == "__main__":
    GeneralApp().mainloop()

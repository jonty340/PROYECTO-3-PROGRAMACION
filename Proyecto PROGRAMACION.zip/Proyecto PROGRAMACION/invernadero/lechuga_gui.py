"""
lechuga_gui.py — Ventana de Monitoreo de la Lechuga
Recomendaciones, estado de variables y control de plagas en tiempo real.
"""

import tkinter as tk
import sys, os

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, BASE_DIR)

from sensor_data import get_manager, RANGOS_OPTIMOS

try:
    import matplotlib
    matplotlib.use("TkAgg")
    from matplotlib.figure import Figure
    from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
    HAS_MPL = True
except ImportError:
    HAS_MPL = False

# ─── Colores temáticos — verde lechuga ──────────────────────────────────────
BG       = "#0a1a0a"
BG2      = "#101f10"
BG3      = "#1a3020"
ACCENT   = "#66BB6A"
ACCENT2  = "#A5D6A7"
GREEN    = "#4CAF50"
YELLOW   = "#FFD54F"
RED      = "#EF5350"
BLUE     = "#42A5F5"
TEXT     = "#E8F5E9"
TEXT2    = "#A5D6A7"
TEXT_DIM = "#2e5c2e"
CULTIVO  = "lechuga"


def _nivel_color(riesgo):
    if riesgo >= 70: return "#EF5350", "ALTO"
    if riesgo >= 40: return "#FF7043", "MEDIO"
    return "#4CAF50", "BAJO"


class LechugaApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("🥬 Monitor de Lechuga")
        self.configure(bg=BG)
        self.geometry("980x720")
        self.resizable(True, True)
        self.manager = get_manager()
        self._build_ui()
        self._update()

    def _build_ui(self):
        hdr = tk.Frame(self, bg="#1b4020", height=60)
        hdr.pack(fill="x")
        hdr.pack_propagate(False)
        btn_volver = tk.Button(hdr, text="⬅ Volver", bg="#0a1a0a", fg=TEXT, font=("Segoe UI", 10, "bold"),
                               relief="flat", cursor="hand2", command=self._volver)
        btn_volver.pack(side="left", padx=(20, 0))
        tk.Label(hdr, text="🥬  MONITOR DE LECHUGA",
                 bg="#1b4020", fg=TEXT, font=("Segoe UI", 20, "bold")).pack(side="left", padx=20, pady=8)
        self.lbl_estado = tk.Label(hdr, text="●  ÓPTIMO",
                                   bg="#1b4020", fg=GREEN, font=("Segoe UI", 13, "bold"))
        self.lbl_estado.pack(side="right", padx=20)

        body = tk.Frame(self, bg=BG)
        body.pack(fill="both", expand=True, padx=10, pady=8)

        left = tk.Frame(body, bg=BG)
        left.pack(side="left", fill="y", padx=(0, 8))
        self._build_vars(left)
        self._build_recomendaciones(left)

        right = tk.Frame(body, bg=BG)
        right.pack(side="left", fill="both", expand=True)
        self._build_plagas(right)
        self._build_graph(right)

    def _build_vars(self, parent):
        frame = tk.LabelFrame(parent, text="  VALORES ACTUALES vs ÓPTIMOS  ",
                              bg=BG2, fg=ACCENT2,
                              font=("Segoe UI", 10, "bold"), bd=1, relief="groove")
        frame.pack(fill="x", pady=(0, 8))
        rangos = RANGOS_OPTIMOS[CULTIVO]
        self.var_widgets = {}
        rows = [
            ("🌡 Temperatura", "temp",        "°C", rangos["temp"]),
            ("💧 Humedad",     "humedad",     "%",  rangos["humedad"]),
            ("☀ Luminosidad",  "luminosidad", "%",  rangos["luminosidad"]),
        ]
        for titulo, key, unit, (lo, hi) in rows:
            row = tk.Frame(frame, bg=BG2)
            row.pack(fill="x", padx=12, pady=6)
            tk.Label(row, text=titulo, bg=BG2, fg=TEXT2,
                     font=("Segoe UI", 10, "bold"), width=16, anchor="w").pack(side="left")
            val_lbl = tk.Label(row, text="--", bg=BG2, fg=TEXT,
                               font=("Segoe UI", 14, "bold"), width=7, anchor="e")
            val_lbl.pack(side="left")
            tk.Label(row, text=unit, bg=BG2, fg=TEXT2, font=("Segoe UI", 9)).pack(side="left", padx=(2, 10))
            tk.Label(row, text=f"Óptimo: {lo}–{hi}{unit}",
                     bg=BG2, fg=TEXT_DIM, font=("Segoe UI", 9)).pack(side="left", padx=4)
            msg_lbl = tk.Label(row, text="", bg=BG2, fg=GREEN, font=("Segoe UI", 9, "bold"))
            msg_lbl.pack(side="left", padx=8)
            self.var_widgets[key] = (val_lbl, msg_lbl)

    def _build_recomendaciones(self, parent):
        frame = tk.LabelFrame(parent, text="  RECOMENDACIONES  ",
                              bg=BG2, fg=ACCENT2,
                              font=("Segoe UI", 10, "bold"), bd=1, relief="groove")
        frame.pack(fill="both", expand=True, pady=(0, 8))
        self.rec_text = tk.Text(frame, bg=BG3, fg=TEXT, font=("Segoe UI", 10),
                                relief="flat", wrap="word", state="disabled", height=8)
        self.rec_text.pack(fill="both", expand=True, padx=8, pady=8)

    def _build_plagas(self, parent):
        frame = tk.LabelFrame(parent, text="  🐛 CONTROL DE PLAGAS  ",
                              bg=BG2, fg=ACCENT2,
                              font=("Segoe UI", 10, "bold"), bd=1, relief="groove")
        frame.pack(fill="x", pady=(0, 8))
        self.plaga_bars = {}
        plagas_nombres = ["Áfidos", "Babosas", "Mildiu Velloso", "Podredumbre Gris"]
        for nombre in plagas_nombres:
            row = tk.Frame(frame, bg=BG2)
            row.pack(fill="x", padx=12, pady=5)
            tk.Label(row, text=nombre, bg=BG2, fg=TEXT2,
                     font=("Segoe UI", 9, "bold"), width=18, anchor="w").pack(side="left")
            bar_bg = tk.Canvas(row, height=18, bg=BG3, highlightthickness=0, width=200)
            bar_bg.pack(side="left", padx=6)
            pct_lbl = tk.Label(row, text="0%", bg=BG2, fg=TEXT,
                               font=("Segoe UI", 9, "bold"), width=5)
            pct_lbl.pack(side="left")
            nivel_lbl = tk.Label(row, text="BAJO", bg=BG2, fg=GREEN,
                                 font=("Segoe UI", 8, "bold"), width=6)
            nivel_lbl.pack(side="left", padx=4)
            info_btn = tk.Button(row, text="ℹ", bg=BG3, fg=TEXT2, relief="flat",
                                 font=("Segoe UI", 9), cursor="hand2", padx=4)
            info_btn.pack(side="left")
            self.plaga_bars[nombre] = (bar_bg, pct_lbl, nivel_lbl, info_btn)

    def _build_graph(self, parent):
        frame = tk.LabelFrame(parent, text="  HISTORIAL (60 lecturas)  ",
                              bg=BG2, fg=ACCENT2,
                              font=("Segoe UI", 10, "bold"), bd=1, relief="groove")
        frame.pack(fill="both", expand=True)
        if not HAS_MPL:
            tk.Label(frame, text="Instala matplotlib", bg=BG2, fg=YELLOW).pack(expand=True)
            return
        self.fig = Figure(figsize=(5, 3.2), dpi=88)
        self.fig.patch.set_facecolor(BG2)
        self.ax = self.fig.add_subplot(111)
        self.ax.set_facecolor(BG3)
        self.ax.tick_params(colors=TEXT2, labelsize=7)
        for sp in self.ax.spines.values():
            sp.set_edgecolor(TEXT_DIM)
        self.line_t, = self.ax.plot([], [], color=ACCENT, linewidth=1.5, label="Temp °C")
        self.line_h, = self.ax.plot([], [], color=BLUE,   linewidth=1.5, label="Humedad %")
        self.line_l, = self.ax.plot([], [], color=YELLOW, linewidth=1.5, label="Luz %")
        self.ax.legend(facecolor=BG3, labelcolor=TEXT2, fontsize=7)
        self.fig.tight_layout(pad=1.0)
        cv = FigureCanvasTkAgg(self.fig, master=frame)
        cv.draw()
        cv.get_tk_widget().pack(fill="both", expand=True, padx=6, pady=6)
        self.cv = cv

    def _update(self):
        data   = self.manager.current
        recs   = self.manager.get_recomendaciones(CULTIVO)
        plagas = self.manager.get_riesgo_plagas(CULTIVO)
        rangos = RANGOS_OPTIMOS[CULTIVO]

        vals = {"temp": data.temperature, "humedad": data.humidity, "luminosidad": data.luminosity}
        for key, (val_lbl, msg_lbl) in self.var_widgets.items():
            v = vals[key]
            val_lbl.config(text=f"{v:.1f}")
            rec    = recs.get(key, {})
            estado = rec.get("estado", "optimo")
            msg    = rec.get("msg", "")
            col    = GREEN if estado == "optimo" else (RED if estado == "alto" else BLUE)
            val_lbl.config(fg=col); msg_lbl.config(text=msg, fg=col)

        gen = recs.get("general", "optimo")
        self.lbl_estado.config(
            text={"optimo": "●  ÓPTIMO", "atencion": "●  ATENCIÓN", "critico": "●  CRÍTICO"}[gen],
            fg={"optimo": GREEN, "atencion": YELLOW, "critico": RED}[gen]
        )

        self.rec_text.config(state="normal")
        self.rec_text.delete("1.0", "end")
        lineas = [
            "━━━ RECOMENDACIONES PARA LECHUGA ━━━\n",
            f"  🌡 Temperatura: {data.temperature:.1f}°C — {recs['temp']['msg']}\n",
            f"  💧 Humedad:     {data.humidity:.1f}%  — {recs['humedad']['msg']}\n",
            f"  ☀ Luminosidad: {data.luminosity:.1f}%  — {recs['luminosidad']['msg']}\n\n",
            "━━━ ACCIONES SUGERIDAS ━━━\n",
        ]
        if gen == "optimo":
            lineas.append("  ✔ Condiciones ideales para lechuga. Mantener el sistema.\n")
        else:
            t_est = recs["temp"]["estado"]
            h_est = recs["humedad"]["estado"]
            l_est = recs["luminosidad"]["estado"]
            if t_est == "alto":
                lineas.append("  🌀 Ventilación necesaria — la lechuga no tolera calor excesivo.\n")
            elif t_est == "bajo":
                lineas.append("  🔥 Aumentar temperatura — proteger de heladas.\n")
            if h_est == "alto":
                lineas.append("  💨 Reducir humedad — previene moho y babosas.\n")
            elif h_est == "bajo":
                lineas.append("  🚿 Aumentar riego — la lechuga necesita humedad constante.\n")
            if l_est == "bajo":
                lineas.append("  💡 Encender LEDs de crecimiento.\n")
            elif l_est == "alto":
                lineas.append("  🕶 Instalar malla sombra — la lechuga prefiere luz difusa.\n")
        self.rec_text.insert("end", "".join(lineas))
        self.rec_text.config(state="disabled")

        nombres_plagas = ["Áfidos", "Babosas", "Mildiu Velloso", "Podredumbre Gris"]
        for (nombre, riesgo, desc), key in zip(plagas, nombres_plagas):
            if key not in self.plaga_bars:
                continue
            bar_bg, pct_lbl, nivel_lbl, info_btn = self.plaga_bars[key]
            color, nivel = _nivel_color(riesgo)
            bar_bg.delete("all")
            w = int(200 * riesgo / 100)
            if w > 0:
                bar_bg.create_rectangle(0, 0, w, 18, fill=color, outline="")
            bar_bg.create_text(100, 9, text=f"{riesgo}%", fill="white", font=("Segoe UI", 8, "bold"))
            pct_lbl.config(text=f"{riesgo}%")
            nivel_lbl.config(text=nivel, fg=color)
            info_btn.config(command=lambda d=desc, n=nombre: self._show_info(n, d))

        if HAS_MPL:
            t_h = list(self.manager.history["temperature"])
            h_h = list(self.manager.history["humidity"])
            l_h = list(self.manager.history["luminosity"])
            x = list(range(len(t_h)))
            self.line_t.set_data(x, t_h)
            self.line_h.set_data(x, h_h)
            self.line_l.set_data(x, l_h)
            all_vals = t_h + h_h + l_h
            if all_vals:
                mn, mx = min(all_vals), max(all_vals)
                self.ax.set_xlim(0, max(60, len(x)))
                self.ax.set_ylim(mn - 5, mx + 5)
            self.cv.draw_idle()

        self.after(1000, self._update)

    def _show_info(self, nombre, desc):
        w = tk.Toplevel(self)
        w.title(f"🐛 {nombre}")
        w.configure(bg=BG2)
        w.geometry("400x220")
        tk.Label(w, text=f"🐛 {nombre}", bg=BG2, fg=ACCENT,
                 font=("Segoe UI", 14, "bold")).pack(pady=12)
        tk.Label(w, text=desc, bg=BG2, fg=TEXT, font=("Segoe UI", 10),
                 wraplength=360, justify="left").pack(padx=20)
        tk.Button(w, text="Cerrar", bg=ACCENT, fg="white", relief="flat",
                  font=("Segoe UI", 10), command=w.destroy).pack(pady=16)

    def _volver(self):
        import subprocess
        script_path = os.path.join(BASE_DIR, "main_gui.py")
        if os.path.exists(script_path):
            subprocess.Popen([sys.executable, script_path])
        self.destroy()


if __name__ == "__main__":
    LechugaApp().mainloop()

@echo off
chcp 65001 > nul
title Instalador — Invernadero Inteligente
color 0B

echo.
echo ===============================================
echo   INSTALADOR DEL SISTEMA DE INVERNADERO
echo ===============================================
echo.
echo Instalando dependencias de Python...
echo.

set PYTHON=C:\Users\Miper\AppData\Local\Programs\Python\Python312\python.exe
if not exist "%PYTHON%" set PYTHON=python

"%PYTHON%" -m pip install --upgrade pip
"%PYTHON%" -m pip install -r requirements.txt

if %ERRORLEVEL% NEQ 0 (
    echo.
    echo [ERROR] Hubo un problema instalando las dependencias.
    echo Asegurate de tener Python instalado y en el PATH.
    pause
    exit /b 1
)

echo.
echo ===============================================
echo   INSTALACION COMPLETADA EXITOSAMENTE
echo ===============================================
echo.
echo Ahora puedes:
echo  1. Ejecutar la aplicacion principal:
echo     python main_gui.py
echo.
echo  2. Compilar los modulos C++ (desde la carpeta cpp):
echo     cd cpp
echo     compile.bat
echo.
pause

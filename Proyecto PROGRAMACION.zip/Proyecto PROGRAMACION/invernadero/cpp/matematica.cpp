/**
 * matematica.cpp — Estadísticas de sensores del invernadero
 *
 * Uso: matematica.exe <valores_CSV>
 * Ejemplo: matematica.exe "24.5,24.8,25.1,24.3,23.9"
 *
 * Salida (stdout, formato clave:valor):
 *   media:24.72
 *   std:0.44
 *   minimo:23.90
 *   maximo:25.10
 *   tendencia:subiendo
 *   pendiente:0.15
 */

#include "matematica.h"
#include <iomanip>
#include <cstdlib>

int main(int argc, char* argv[]) {
    if (argc < 2) {
        std::cerr << "Uso: matematica.exe <valores_separados_por_coma>" << std::endl;
        return 1;
    }

    std::vector<double> datos = parsear_csv(std::string(argv[1]));

    if (datos.empty()) {
        std::cerr << "Error: no se pudieron parsear los datos." << std::endl;
        return 2;
    }

    double media     = calcular_media(datos);
    double std_dev   = calcular_std(datos);
    double minimo    = calcular_min(datos);
    double maximo    = calcular_max(datos);
    double pendiente = calcular_pendiente(datos);
    std::string tendencia = determinar_tendencia(pendiente);

    // Media móvil de 5 puntos
    std::vector<double> suavizado = media_movil(datos, 5);

    std::cout << std::fixed << std::setprecision(2);
    std::cout << "media:"     << media             << "\n";
    std::cout << "std:"       << std_dev           << "\n";
    std::cout << "minimo:"    << minimo             << "\n";
    std::cout << "maximo:"    << maximo             << "\n";
    std::cout << "tendencia:" << tendencia          << "\n";
    std::cout << "pendiente:" << pendiente          << "\n";
    std::cout << "n:"         << datos.size()       << "\n";

    // Último valor suavizado
    if (!suavizado.empty()) {
        std::cout << "suavizado_ultimo:" << suavizado.back() << "\n";
    }

    return 0;
}

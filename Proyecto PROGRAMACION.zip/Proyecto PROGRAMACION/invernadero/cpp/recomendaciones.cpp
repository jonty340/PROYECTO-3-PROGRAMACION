/**
 * recomendaciones.cpp — Motor de recomendaciones por cultivo
 *
 * Uso: recomendaciones.exe <cultivo> <temperatura> <humedad> <luminosidad>
 * Ejemplo: recomendaciones.exe tomate 28.5 70.0 85.0
 *
 * Salida (stdout):
 *   temp_delta:1.5
 *   temp_estado:alto
 *   temp_rec:Bajar temperatura 1.5 grados abriendo ventilacion
 *   humedad_delta:0.0
 *   humedad_estado:optimo
 *   humedad_rec:Humedad en rango optimo
 *   luz_delta:0.0
 *   luz_estado:optimo
 *   luz_rec:Luminosidad en rango optimo
 *   estado_general:atencion
 */

#include <iostream>
#include <string>
#include <cmath>
#include <cstdlib>
#include <iomanip>

struct Rango {
    double lo, hi;
};

struct CultivoRangos {
    Rango temp;
    Rango humedad;
    Rango luz;
};

CultivoRangos obtener_rangos(const std::string& cultivo) {
    if (cultivo == "tomate") {
        return {{18.0, 27.0}, {65.0, 85.0}, {70.0, 90.0}};
    } else if (cultivo == "lechuga") {
        return {{15.0, 20.0}, {60.0, 70.0}, {50.0, 75.0}};
    } else if (cultivo == "pimiento") {
        return {{20.0, 30.0}, {60.0, 80.0}, {65.0, 85.0}};
    }
    // Equilibrio general
    return {{18.0, 27.0}, {62.0, 78.0}, {60.0, 80.0}};
}

struct ResultadoVar {
    double delta;
    std::string estado;   // "optimo", "alto", "bajo"
    std::string rec;
};

ResultadoVar analizar(double valor, Rango r,
                      const std::string& var_nombre,
                      const std::string& cultivo) {
    ResultadoVar res;

    if (valor < r.lo) {
        res.delta  = r.lo - valor;
        res.estado = "bajo";
        if (var_nombre == "temp") {
            res.rec = "Temperatura baja: activar calefaccion o cerrar ventanas (+";
        } else if (var_nombre == "humedad") {
            res.rec = "Humedad insuficiente: aumentar riego o nebulizacion (+";
        } else {
            res.rec = "Luminosidad baja: activar lamparas LED de crecimiento (+";
        }
        // Redondear delta a 1 decimal
        std::ostringstream ss;
        ss << std::fixed << std::setprecision(1) << res.delta;
        res.rec += ss.str() + "%)";
    } else if (valor > r.hi) {
        res.delta  = valor - r.hi;
        res.estado = "alto";
        if (var_nombre == "temp") {
            res.rec = "Temperatura alta: abrir ventilacion o activar enfriamiento (-";
        } else if (var_nombre == "humedad") {
            res.rec = "Humedad excesiva: reducir riego y mejorar ventilacion (-";
        } else {
            res.rec = "Luminosidad excesiva: instalar malla sombra (-";
        }
        std::ostringstream ss;
        ss << std::fixed << std::setprecision(1) << res.delta;
        res.rec += ss.str() + "%)";
    } else {
        res.delta  = 0.0;
        res.estado = "optimo";
        if (var_nombre == "temp")    res.rec = "Temperatura en rango optimo. Mantener.";
        else if (var_nombre == "humedad") res.rec = "Humedad en rango optimo. Mantener.";
        else                         res.rec = "Luminosidad en rango optimo. Mantener.";
    }

    return res;
}

int main(int argc, char* argv[]) {
    if (argc < 5) {
        std::cerr << "Uso: recomendaciones.exe <cultivo> <temp> <humedad> <luminosidad>" << std::endl;
        return 1;
    }

    std::string cultivo = argv[1];
    double temp   = std::atof(argv[2]);
    double humedad = std::atof(argv[3]);
    double luz    = std::atof(argv[4]);

    CultivoRangos rangos = obtener_rangos(cultivo);

    auto r_temp = analizar(temp,    rangos.temp,    "temp",    cultivo);
    auto r_hum  = analizar(humedad, rangos.humedad, "humedad", cultivo);
    auto r_luz  = analizar(luz,     rangos.luz,     "luz",     cultivo);

    // Estado general
    int problemas = 0;
    if (r_temp.estado != "optimo") problemas++;
    if (r_hum.estado  != "optimo") problemas++;
    if (r_luz.estado  != "optimo") problemas++;

    std::string estado_general;
    if (problemas == 0)      estado_general = "optimo";
    else if (problemas == 1) estado_general = "atencion";
    else                     estado_general = "critico";

    // Porcentaje de ajuste de ventilación sugerido
    double vent_pct = 0.0;
    if (r_temp.estado == "alto")   vent_pct += r_temp.delta * 5.0;
    if (r_hum.estado  == "alto")   vent_pct += r_hum.delta  * 2.0;
    vent_pct = std::min(vent_pct, 100.0);

    std::cout << std::fixed << std::setprecision(2);
    std::cout << "temp_delta:"    << r_temp.delta  << "\n";
    std::cout << "temp_estado:"   << r_temp.estado << "\n";
    std::cout << "temp_rec:"      << r_temp.rec    << "\n";
    std::cout << "humedad_delta:" << r_hum.delta   << "\n";
    std::cout << "humedad_estado:"<< r_hum.estado  << "\n";
    std::cout << "humedad_rec:"   << r_hum.rec     << "\n";
    std::cout << "luz_delta:"     << r_luz.delta   << "\n";
    std::cout << "luz_estado:"    << r_luz.estado  << "\n";
    std::cout << "luz_rec:"       << r_luz.rec     << "\n";
    std::cout << "estado_general:"<< estado_general<< "\n";
    std::cout << "ventilacion_pct:"<< vent_pct     << "\n";

    return 0;
}

/**
 * plagas.cpp — Cálculo de riesgo de plagas por cultivo
 *
 * Uso: plagas.exe <cultivo> <temperatura> <humedad>
 * Ejemplo: plagas.exe tomate 28.5 90.0
 *
 * Salida (stdout):
 *   PLAGA:<nombre>:<riesgo_0_100>:<nivel>:<descripcion>
 */

#include <iostream>
#include <string>
#include <vector>
#include <algorithm>
#include <cstdlib>
#include <cmath>

struct InfoPlaga {
    std::string nombre;
    int         riesgo;   // 0–100
    std::string nivel;    // "Bajo", "Medio", "Alto"
    std::string descripcion;
};

int clamp(int v) { return std::max(0, std::min(100, v)); }

std::string nivel_riesgo(int r) {
    if (r >= 70) return "Alto";
    if (r >= 40) return "Medio";
    return "Bajo";
}

std::vector<InfoPlaga> calcular_tomate(double temp, double hum) {
    std::vector<InfoPlaga> plagas;

    // Araña Roja: favorecida por temperatura alta y baja humedad
    int r_arana = clamp((int)((temp - 22) * 5.0 + (70 - hum) * 1.2));
    plagas.push_back({"Arana_Roja", r_arana, nivel_riesgo(r_arana),
        "Alta temperatura y baja humedad favorecen su aparicion. "
        "Revisar el enves de las hojas. Aplicar acaricida si es necesario."});

    // Afidos: prefieren humedad alta y temperatura moderada
    int r_afidos = clamp((int)((hum - 65) * 1.5 + (25 - temp) * 2.0));
    plagas.push_back({"Afidos", r_afidos, nivel_riesgo(r_afidos),
        "Prefieren brotes tiernos con alta humedad. "
        "Usar jabon potasico o insecticida sistemico."});

    // Mosca Blanca: temperatura alta
    int r_mosca = clamp((int)((temp - 24) * 4.5 + (hum - 60) * 0.5));
    plagas.push_back({"Mosca_Blanca", r_mosca, nivel_riesgo(r_mosca),
        "Alta temperatura facilita su reproduccion. "
        "Colocar trampas amarillas y controlar con insecticida."});

    // Tizon Tardio: humedad alta y temperaturas frescas
    int r_tizon = clamp((int)((hum - 75) * 2.5 + (22 - temp) * 1.5));
    plagas.push_back({"Tizon_Tardio", r_tizon, nivel_riesgo(r_tizon),
        "Hongo favorecido por alta humedad y temperaturas frescas. "
        "Mejorar ventilacion y aplicar fungicida cuprico."});

    return plagas;
}

std::vector<InfoPlaga> calcular_lechuga(double temp, double hum) {
    std::vector<InfoPlaga> plagas;

    int r_afidos = clamp((int)((hum - 60) * 1.0 + (22 - temp) * 1.5));
    plagas.push_back({"Afidos", r_afidos, nivel_riesgo(r_afidos),
        "Prefieren hojas internas. Revisar frecuentemente. "
        "Usar jabon potasico o extracto de ajo."});

    int r_babosas = clamp((int)((hum - 65) * 2.0 + (20 - temp) * 1.0));
    plagas.push_back({"Babosas", r_babosas, nivel_riesgo(r_babosas),
        "Alta humedad y temperaturas bajas las activan. "
        "Usar cebos ecologicos y reducir humedad en suelo."});

    int r_mildiu = clamp((int)((hum - 70) * 2.5 + (20 - temp) * 0.8));
    plagas.push_back({"Mildiu_Velloso", r_mildiu, nivel_riesgo(r_mildiu),
        "Hongo que aparece con alta humedad y temperatura fresca. "
        "Mejorar ventilacion, evitar mojar las hojas."});

    int r_podred = clamp((int)((hum - 75) * 3.0));
    plagas.push_back({"Podredumbre_Gris", r_podred, nivel_riesgo(r_podred),
        "Botrytis favorecida por humedad superior al 80 por ciento. "
        "Eliminar hojas afectadas y aplicar fungicida."});

    return plagas;
}

std::vector<InfoPlaga> calcular_pimiento(double temp, double hum) {
    std::vector<InfoPlaga> plagas;

    int r_arana = clamp((int)((temp - 24) * 5.0 + (65 - hum) * 1.2));
    plagas.push_back({"Arana_Roja", r_arana, nivel_riesgo(r_arana),
        "Baja humedad y alta temperatura son factores de riesgo. "
        "Mantener humedad adecuada y usar acaricidas si es necesario."});

    int r_afidos = clamp((int)((hum - 60) * 1.0 + (25 - temp) * 1.2));
    plagas.push_back({"Afidos", r_afidos, nivel_riesgo(r_afidos),
        "Transmiten virus entre plantas. Revisar semanalmente. "
        "Usar insecticidas o enemigos naturales como la mariquita."});

    int r_mancha = clamp((int)((hum - 65) * 1.8 + (temp - 22) * 1.5));
    plagas.push_back({"Mancha_Bacteriana", r_mancha, nivel_riesgo(r_mancha),
        "Alta humedad y temperatura calida favorecen la bacteria. "
        "Evitar mojar el follaje. Aplicar cobre preventivamente."});

    int r_botry = clamp((int)((hum - 70) * 2.0 + (temp - 20) * 0.8));
    plagas.push_back({"Botrytis", r_botry, nivel_riesgo(r_botry),
        "Alta humedad y temperatura moderada-alta la favorecen. "
        "Mejorar aireacion y retirar tejidos afectados."});

    return plagas;
}

int main(int argc, char* argv[]) {
    if (argc < 4) {
        std::cerr << "Uso: plagas.exe <cultivo> <temperatura> <humedad>" << std::endl;
        return 1;
    }

    std::string cultivo = argv[1];
    double temp = std::atof(argv[2]);
    double hum  = std::atof(argv[3]);

    std::vector<InfoPlaga> plagas;

    if (cultivo == "tomate")       plagas = calcular_tomate(temp, hum);
    else if (cultivo == "lechuga") plagas = calcular_lechuga(temp, hum);
    else if (cultivo == "pimiento")plagas = calcular_pimiento(temp, hum);
    else {
        std::cerr << "Cultivo no reconocido. Use: tomate, lechuga o pimiento." << std::endl;
        return 2;
    }

    for (const auto& p : plagas) {
        std::cout << "PLAGA:" << p.nombre << ":"
                  << p.riesgo << ":"
                  << p.nivel  << ":"
                  << p.descripcion << "\n";
    }

    return 0;
}

/**
 * matematica.h — Cabeceras del módulo matemático del invernadero
 * Funciones de estadística, tendencias y media móvil.
 */

#pragma once
#include <vector>
#include <string>
#include <cmath>
#include <algorithm>
#include <numeric>
#include <sstream>
#include <iostream>

// ─── Parsing ────────────────────────────────────────────────────────────────
std::vector<double> parsear_csv(const std::string& csv) {
    std::vector<double> resultado;
    std::stringstream ss(csv);
    std::string token;
    while (std::getline(ss, token, ',')) {
        try { resultado.push_back(std::stod(token)); }
        catch (...) {}
    }
    return resultado;
}

// ─── Estadísticas básicas ────────────────────────────────────────────────────
double calcular_media(const std::vector<double>& d) {
    if (d.empty()) return 0.0;
    return std::accumulate(d.begin(), d.end(), 0.0) / d.size();
}

double calcular_std(const std::vector<double>& d) {
    if (d.size() < 2) return 0.0;
    double m = calcular_media(d);
    double var = 0.0;
    for (double v : d) var += (v - m) * (v - m);
    return std::sqrt(var / d.size());
}

double calcular_min(const std::vector<double>& d) {
    if (d.empty()) return 0.0;
    return *std::min_element(d.begin(), d.end());
}

double calcular_max(const std::vector<double>& d) {
    if (d.empty()) return 0.0;
    return *std::max_element(d.begin(), d.end());
}

// ─── Regresión lineal (pendiente) ────────────────────────────────────────────
double calcular_pendiente(const std::vector<double>& d) {
    int n = (int)d.size();
    if (n < 2) return 0.0;
    double x_mean = (n - 1) / 2.0;
    double y_mean = calcular_media(d);
    double num = 0.0, den = 0.0;
    for (int i = 0; i < n; i++) {
        num += (i - x_mean) * (d[i] - y_mean);
        den += (i - x_mean) * (i - x_mean);
    }
    return (den != 0.0) ? num / den : 0.0;
}

std::string determinar_tendencia(double pendiente) {
    if (pendiente >  0.05) return "subiendo";
    if (pendiente < -0.05) return "bajando";
    return "estable";
}

// ─── Media móvil ─────────────────────────────────────────────────────────────
std::vector<double> media_movil(const std::vector<double>& d, int ventana) {
    std::vector<double> resultado;
    int n = (int)d.size();
    for (int i = 0; i < n; i++) {
        int ini = std::max(0, i - ventana + 1);
        double suma = 0.0;
        for (int j = ini; j <= i; j++) suma += d[j];
        resultado.push_back(suma / (i - ini + 1));
    }
    return resultado;
}

/**
 * graficas.cpp — Procesamiento de datos para gráficas
 *
 * Uso: graficas.exe <valores_CSV> [ventana_suavizado]
 * Ejemplo: graficas.exe "24.5,24.8,25.1,24.3,23.9,24.6" 3
 *
 * Salida:
 *   ORIGINAL:<v1,v2,v3,...>
 *   SUAVIZADO:<v1,v2,v3,...>
 *   MIN:<valor>
 *   MAX:<valor>
 *   UMBRAL_BAJO:<valor>
 *   UMBRAL_ALTO:<valor>
 *   CRUCES:<n>   (cantidad de veces que cruza umbrales)
 */

#include "matematica.h"
#include <iomanip>
#include <cstdlib>

int main(int argc, char* argv[]) {
    if (argc < 2) {
        std::cerr << "Uso: graficas.exe <valores_CSV> [ventana=5] [umbral_bajo] [umbral_alto]" << std::endl;
        return 1;
    }

    std::vector<double> datos = parsear_csv(std::string(argv[1]));
    int ventana = (argc >= 3) ? std::atoi(argv[2]) : 5;
    double umbral_bajo = (argc >= 4) ? std::atof(argv[3]) : calcular_media(datos) - calcular_std(datos);
    double umbral_alto = (argc >= 5) ? std::atof(argv[4]) : calcular_media(datos) + calcular_std(datos);

    if (datos.empty()) {
        std::cerr << "Error: sin datos válidos." << std::endl;
        return 2;
    }

    std::vector<double> suavizado = media_movil(datos, ventana);
    double vmin = calcular_min(datos);
    double vmax = calcular_max(datos);

    // Contar cruces de umbral
    int cruces = 0;
    for (size_t i = 1; i < datos.size(); i++) {
        bool prev_fuera = (datos[i-1] < umbral_bajo || datos[i-1] > umbral_alto);
        bool curr_fuera = (datos[i]   < umbral_bajo || datos[i]   > umbral_alto);
        if (prev_fuera != curr_fuera) cruces++;
    }

    // Salida
    std::cout << std::fixed << std::setprecision(2);

    // Original
    std::cout << "ORIGINAL:";
    for (size_t i = 0; i < datos.size(); i++) {
        if (i > 0) std::cout << ",";
        std::cout << datos[i];
    }
    std::cout << "\n";

    // Suavizado
    std::cout << "SUAVIZADO:";
    for (size_t i = 0; i < suavizado.size(); i++) {
        if (i > 0) std::cout << ",";
        std::cout << suavizado[i];
    }
    std::cout << "\n";

    std::cout << "MIN:"          << vmin         << "\n";
    std::cout << "MAX:"          << vmax         << "\n";
    std::cout << "UMBRAL_BAJO:"  << umbral_bajo  << "\n";
    std::cout << "UMBRAL_ALTO:"  << umbral_alto  << "\n";
    std::cout << "CRUCES:"       << cruces       << "\n";
    std::cout << "TENDENCIA:"    << determinar_tendencia(calcular_pendiente(datos)) << "\n";

    return 0;
}

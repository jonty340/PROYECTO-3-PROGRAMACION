@echo off
chcp 65001 > nul
title Compilador C++ — Invernadero Inteligente
color 0A

echo.
echo ===============================================
echo   COMPILANDO MODULOS C++ DEL INVERNADERO
echo ===============================================
echo.

REM ─── Buscar g++ en el PATH y ubicaciones comunes ─────────────────────────
set GXX=
where g++ >nul 2>&1
if %ERRORLEVEL% EQU 0 (
    set GXX=g++
    echo [OK] Compilador encontrado en PATH: g++
    goto :compilar
)

REM Ruta directa de WinLibs instalado
set WINLIBS_GXX=%LOCALAPPDATA%\Microsoft\WinGet\Packages\BrechtSanders.WinLibs.POSIX.UCRT_Microsoft.Winget.Source_8wekyb3d8bbwe\mingw64\bin\g++.exe
if exist "%WINLIBS_GXX%" (
    set GXX=%WINLIBS_GXX%
    echo [OK] WinLibs encontrado
    goto :compilar
)

REM Buscar en WinLibs (instalado por winget)
for /d %%D in ("%LOCALAPPDATA%\Microsoft\WinGet\Packages\BrechtSanders*") do (
    if exist "%%D\mingw64\bin\g++.exe" (
        set GXX=%%D\mingw64\bin\g++.exe
        echo [OK] WinLibs encontrado: %%D\mingw64\bin\g++.exe
        goto :compilar
    )
)

REM Buscar en ubicaciones tipicas de MinGW
for %%P in (
    "C:\mingw64\bin\g++.exe"
    "C:\MinGW\bin\g++.exe"
    "C:\msys64\mingw64\bin\g++.exe"
    "C:\TDM-GCC-64\bin\g++.exe"
    "C:\ProgramData\chocolatey\bin\g++.exe"
) do (
    if exist %%P (
        set GXX=%%P
        echo [OK] Compilador encontrado en %%P
        goto :compilar
    )
)

echo [ERROR] No se encontro g++.
echo.
echo Ejecuta instalar.bat para instalar el compilador automaticamente,
echo o instala MinGW/WinLibs manualmente y agrega g++ al PATH.
echo.
pause
exit /b 1

:compilar
echo.
echo Compilando matematica.cpp ...
"%GXX%" -o matematica.exe matematica.cpp -std=c++17 -O2 -static
if %ERRORLEVEL% NEQ 0 (
    echo [ERROR] Fallo la compilacion de matematica.cpp
    pause
    exit /b 1
)
echo [OK] matematica.exe generado

echo.
echo Compilando recomendaciones.cpp ...
"%GXX%" -o recomendaciones.exe recomendaciones.cpp -std=c++17 -O2 -static
if %ERRORLEVEL% NEQ 0 (
    echo [ERROR] Fallo la compilacion de recomendaciones.cpp
    pause
    exit /b 1
)
echo [OK] recomendaciones.exe generado

echo.
echo Compilando plagas.cpp ...
"%GXX%" -o plagas.exe plagas.cpp -std=c++17 -O2 -static
if %ERRORLEVEL% NEQ 0 (
    echo [ERROR] Fallo la compilacion de plagas.cpp
    pause
    exit /b 1
)
echo [OK] plagas.exe generado

echo.
echo Compilando graficas.cpp ...
"%GXX%" -o graficas.exe graficas.cpp -std=c++17 -O2 -static
if %ERRORLEVEL% NEQ 0 (
    echo [ERROR] Fallo la compilacion de graficas.cpp
    pause
    exit /b 1
)
echo [OK] graficas.exe generado

echo.
echo ===============================================
echo   COMPILACION EXITOSA - 4 ejecutables listos
echo   matematica.exe
echo   recomendaciones.exe
echo   plagas.exe
echo   graficas.exe
echo ===============================================
echo.
echo Prueba rapida:
echo   matematica.exe "24.5,24.8,25.1,24.3,23.9"
echo   recomendaciones.exe tomate 28.5 70.0 85.0
echo   plagas.exe tomate 29.0 88.0
echo   graficas.exe "24.5,24.8,25.1,24.3,23.9" 3
echo.
pause
